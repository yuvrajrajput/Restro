package com.example.shivam.travelous;

import android.view.View;

public interface ItemClickListner {
    void onItemclick(View v, int pos);
}
