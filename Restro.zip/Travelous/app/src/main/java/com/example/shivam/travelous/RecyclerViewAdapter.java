package com.example.shivam.travelous;

import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        public TextView name;
        public TextView address;
        public ImageView imageView;
        public CardView cardView1;
        public TextView thomerating;
        ItemClickListner itemClickListener;

        public ViewHolder(final View itemView) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.thomename);
            address=itemView.findViewById(R.id.thomeaddress);
            imageView=itemView.findViewById(R.id.thproimage);
            cardView1=itemView.findViewById(R.id.cardview1);
            thomerating=itemView.findViewById(R.id.thomeratings);
            /*itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });*/
        }

        @Override
        public void onClick(View v) {
            this.itemClickListener.onItemclick(v,getLayoutPosition());
        }
        public void setItemClickListener(ItemClickListner ic){
            this.itemClickListener=ic;
        }
    }
    private List<Property> aproperty;
    Context context;

    public RecyclerViewAdapter(List<Property> properties,Context c) {
        this.aproperty=properties;
        this.context=c;

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        Context context =viewGroup.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View contactView = inflater.inflate(R.layout.property_viewholder,viewGroup, false);
        ViewHolder viewHolder = new ViewHolder(contactView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        Property property=aproperty.get(i);
        Property property1=aproperty.get(i);
        TextView name=viewHolder.name;
        name.setText(property.getname());
        TextView address=viewHolder.address;
        address.setText(property.getaddress());
        ImageView imageView=viewHolder.imageView;
        TextView ratings=viewHolder.thomerating;
        ratings.setText(Integer.toString(property.getid()));
        imageView.setImageBitmap(BitmapFactory.decodeByteArray(property.getimage(),0,property.getimage().length));
        final String s1=Integer.toString(property.getid());
        final String name1=property.getname();
        final String address1=property.getaddress();
        final String tname=property.gettname();
        final String temail=property.gettemail();
        viewHolder.cardView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(context,BrowsePropertyActivity.class);
                i.putExtra("pname",name1);
                i.putExtra("id",s1);
                i.putExtra("address",address1);
                i.putExtra("tname",tname);
                i.putExtra("temail",temail);
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return aproperty.size();
    }


}
