package com.example.shivam.travelous;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.CardView;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import de.hdodenhof.circleimageview.CircleImageView;

public class HhomeActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
TextView t1,t2;
CardView home,restaurant;
DbHelper obj;
Button test;
String flag;
CircleImageView view1;
CardView hhomecv1,hhomecv2,hhomecv3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hhome);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View headerview=navigationView.getHeaderView(0);


        t1=(TextView)headerview.findViewById(R.id.hostname);
        t2=(TextView)headerview.findViewById(R.id.hostemail);
        hhomecv1=findViewById(R.id.hhomecv1);
        hhomecv2=findViewById(R.id.hhomecv2);
        hhomecv3=findViewById(R.id.hhomecv3);
        hhomecv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(),MyPlacesActivity.class);
                putextraah(i);
                startActivity(i);
            }
        });
        hhomecv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(),SupportActivity.class);
                startActivity(i);
            }
        });
        hhomecv3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(i);
                finish();
            }
        });
        view1=headerview.findViewById(R.id.hhmomeimage);
        final String name1=getIntent().getStringExtra("name").toString();
        final String email1=getIntent().getStringExtra("email").toString();
        t1.setText(name1);
        t2.setText(email1);
        //get pic
        obj=new DbHelper(this);
        Cursor c1 = obj.gethostid(name1,email1);
        final int valid = c1.getColumnIndex("hpic");
        byte[]image;
        c1.moveToFirst();
        image = c1.getBlob(valid);
        if (image!=null) {
            view1.setImageBitmap(BitmapFactory.decodeByteArray(image, 0, image.length));
        }
        home=(CardView)findViewById(R.id.addhome);
        restaurant=(CardView)findViewById(R.id.restaurant);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flag="HOME";
                Intent i1=new Intent(getApplicationContext(),HostAddPropertyActivity.class);
                i1.putExtra("hostname",t1.getText().toString());
                i1.putExtra("hostemail",t2.getText().toString());
                i1.putExtra("category",flag);
                startActivity(i1);
            }
        });
        restaurant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flag="RESTAURANT";
                Intent i=new Intent(getApplicationContext(),HostAddPropertyActivity.class);
                i.putExtra("hostname1",t1.getText().toString());
                i.putExtra("hostemail1",t2.getText().toString());
                i.putExtra("category",flag);
                startActivity(i);
            }
        });
    }
    public void putextraah(Intent i1){
        flag="HOME";
        i1.putExtra("hostname",t1.getText().toString());
        i1.putExtra("hostemail",t2.getText().toString());
        i1.putExtra("category",flag);
    }
    public void putextraar(Intent i){
        flag="RESTAURANT";
        i.putExtra("hostname1",t1.getText().toString());
        i.putExtra("hostemail1",t2.getText().toString());
        i.putExtra("category",flag);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.hhome, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.hnav_profile) {
            String name1=getIntent().getStringExtra("name");
            String email1=getIntent().getStringExtra("email");
            Intent i=new Intent(getApplicationContext(),HProfileActivity.class);
            i.putExtra("name",name1);
            i.putExtra("email",email1);
            startActivity(i);


        }
        else if (id==R.id.hnav_myplaces){
            Intent i=new Intent(getApplicationContext(),MyPlacesActivity.class);
            putextraah(i);
            startActivity(i);
        }
        else if (id == R.id.hnav_Places) {
            Intent i1=new Intent(getApplicationContext(),HostAddPropertyActivity.class);
            putextraah(i1);
           // Toast.makeText(this, , Toast.LENGTH_SHORT).show();
           // i1.putExtra("hostname",nam);
            //i1.putExtra("hostemail",t2.getText().toString());
            //i1.putExtra("category",flag);
            startActivity(i1);
        } else if (id == R.id.hnav_manage_places) {
            Intent i1=new Intent(getApplicationContext(),HostAddPropertyActivity.class);
            putextraar(i1);
            startActivity(i1);
        } else if (id == R.id.hnav_support) {
            Intent i=new Intent(getApplicationContext(),SupportActivity.class);
            startActivity(i);

        }else if(id==R.id.hnav_logout){
            Intent i=new Intent(getApplicationContext(),MainActivity.class);
            startActivity(i);
            finish();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
