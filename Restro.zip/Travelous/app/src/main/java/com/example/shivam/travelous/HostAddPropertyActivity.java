package com.example.shivam.travelous;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HostAddPropertyActivity extends AppCompatActivity {
Spinner apsp1,apsp2;
DbHelper obj;
int stateid,cityid,selectedcity;
Button reghome,addpropimages;
EditText reghomeet1,reghomeet2,reghomeet3,reghomeet4;
int flag=1;
ImageView imv1,imv2,imv3;
final int REQUEST_CODE_GALLERY=999;
TextInputLayout tip1,tip2,tip3,tip4;
    ArrayList<String> list,list1,list2,list3,list4,list5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_host_add_property);
        obj=new DbHelper(this);
        final String name1=getIntent().getStringExtra("name");
        final String email1=getIntent().getStringExtra("email");
        final String hostname=getIntent().getStringExtra("hostname");
        final String hostemail=getIntent().getStringExtra("hostemail");
        final String hostname1=getIntent().getStringExtra("hostname1");
        final String hostemail1=getIntent().getStringExtra("hostemail1");
        final String category=getIntent().getStringExtra("category");
        //final int hid=Integer.parseInt(id);
        int id=0;
        final String home="HOME";
        final String restau="RESTAURANT";
     //   if (category.equals(home)) {
       //     Cursor c1 = obj.gethostid(hostname, hostemail);
     //       int valid = c1.getColumnIndex("hid");
      //      c1.moveToFirst();
       //     id = c1.getInt(valid);
            //String c=c1.getString(valid);
       // }
     //   if (category.equals(restau)){
       //     Cursor c1=obj.gethostid(hostname1,hostemail1);
         //   int valid =c1.getColumnIndex("hid");
           // c1.moveToFirst();
       //     id=c1.getInt(valid);
      //  }
        final int id1=id;
        startconfig();
        list = new ArrayList<String>();
        list2 = new ArrayList<String>();
        spinner1();
        spinner2();


        addpropimages.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent,REQUEST_CODE_GALLERY);
            }
        });


        apsp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String m=list1.get(position);
                stateid=Integer.parseInt(m);
                citybind();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        apsp2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String m=list3.get(position);
                cityid=Integer.parseInt(m);
                String s=list4.get(position);
                Cursor c=obj.getonescity(s);
                int c1=c.getColumnIndex("cid");
                c.moveToFirst();
                selectedcity=c.getInt(c1);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        reghome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText( getApplicationContext(),"Iteam Add",Toast.LENGTH_LONG ) .show();
                String name=reghomeet1.getText().toString();
                String address=reghomeet2.getText().toString();
                String pincode=reghomeet3.getText().toString();
                String pancard=reghomeet4.getText().toString();
                if (!isValidPan(pancard)){
                    reghomeet4.setError("Enter A Valid PAN Number");
                }
                if (!isNullRec(name)){
                    reghomeet1.setError("Field Can't Be Empty");
                }
                if(!isNullRec(address)){
                    reghomeet2.setError("Field Can't Be Empty");
                }
                if(!isNullRec(pincode)){
                    reghomeet3.setError("Field Can't Be Empty");
                }
                if(!isNullRec(pancard)){
                    reghomeet4.setError("Field Can't Be Empty");
                }
                if ((isNullRec(name)) && (isNullRec(address)) && (isNullRec(pincode)) && (isNullRec(pancard)) && (isValidPan(pancard)))  {
                    if (flag == 2) {
                        if (category.equals(home)) {
                            if (obj.addproperty1(id1, 1, name, address, pincode, pancard, stateid, selectedcity, imageviewtobyte(imv1))) {
                                Toast.makeText(HostAddPropertyActivity.this, "Property Added!!", Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(getApplicationContext(), AddServicesActivity.class);
                                i.putExtra("name", name1);
                                i.putExtra("email", email1);
                                i.putExtra("pname", name);
                                startActivity(i);
                            } else {
                                Toast.makeText(HostAddPropertyActivity.this, "Registration Failed!!", Toast.LENGTH_SHORT).show();
                            }
                        }
                        if (category.equals(restau)) {
                            if (obj.addproperty1(id1, 2, name, address, pincode, pancard, stateid, selectedcity, imageviewtobyte(imv1))) {
                                Toast.makeText(HostAddPropertyActivity.this, "Property Added!!", Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(getApplicationContext(), AddServicesActivity.class);
                                i.putExtra("name", name1);
                                i.putExtra("email", email1);
                                i.putExtra("pname", name);
                                startActivity(i);
                            } else {
                                Toast.makeText(HostAddPropertyActivity.this, "Registration Failed!!", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                    if (flag == 3) {
                        if (category.equals(home)) {
                            if (obj.addproperty2(id1, 1, name, address, pincode, pancard, stateid, selectedcity, imageviewtobyte(imv1), imageviewtobyte(imv2))) {
                                Toast.makeText(HostAddPropertyActivity.this, "Property Added!!", Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(getApplicationContext(), AddServicesActivity.class);
                                i.putExtra("name", name1);
                                i.putExtra("email", email1);
                                i.putExtra("pname", name);
                                startActivity(i);
                            } else {
                                Toast.makeText(HostAddPropertyActivity.this, "Registration Failed!!", Toast.LENGTH_SHORT).show();
                            }
                        }
                        if (category.equals(restau)) {
                            if (obj.addproperty2(id1, 2, name, address, pincode, pancard, stateid, selectedcity, imageviewtobyte(imv1), imageviewtobyte(imv2))) {
                                Toast.makeText(HostAddPropertyActivity.this, "Property Added!!", Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(getApplicationContext(), AddServicesActivity.class);
                                i.putExtra("name", name1);
                                i.putExtra("email", email1);
                                i.putExtra("pname", name);
                                startActivity(i);
                            } else {
                                Toast.makeText(HostAddPropertyActivity.this, "Registration Failed!!", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                    if (flag == 4) {
                        if (category.equals(home)) {
                            if (obj.addproperty3(id1, 1, name, address, pincode, pancard, stateid, selectedcity, imageviewtobyte(imv1), imageviewtobyte(imv2), imageviewtobyte(imv3))) {
                                Toast.makeText(HostAddPropertyActivity.this, "Property Added!!", Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(getApplicationContext(), AddServicesActivity.class);
                                i.putExtra("name", name1);
                                i.putExtra("email", email1);
                                i.putExtra("pname", name);
                                startActivity(i);
                            } else {
                                Toast.makeText(HostAddPropertyActivity.this, "Registration Failed!!", Toast.LENGTH_SHORT).show();
                            }
                        }
                        if (category.equals(restau)) {
                            if (obj.addproperty3(id1, 2, name, address, pincode, pancard, stateid, selectedcity, imageviewtobyte(imv1), imageviewtobyte(imv2), imageviewtobyte(imv3))) {
                                Toast.makeText(HostAddPropertyActivity.this, "Property Added!!", Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(getApplicationContext(), AddServicesActivity.class);
                                i.putExtra("name", name1);
                                i.putExtra("email", email1);
                                i.putExtra("pname", name);
                                startActivity(i);
                            } else {
                                Toast.makeText(HostAddPropertyActivity.this, "Registration Failed!!", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }
            }
        });

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        // Check which request it is that we're responding to
        // Make sure the request was successful
        if(requestCode==REQUEST_CODE_GALLERY && resultCode==RESULT_OK && data!=null) {
            // Get the URI that points to the selected contact
            Uri uri = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);

                if (flag==1) {
                    imv1.setImageBitmap(bitmap);
                }
                if (flag==2){
                    imv2.setImageBitmap(bitmap);
                }
                if (flag==3){
                    imv3.setImageBitmap(bitmap);
                    addpropimages.setEnabled(false);
                }
                showmsg("Image Display");
                flag++;
            } catch (Exception ex) {
                showmsg(ex.getMessage());
            }

        }
        super.onActivityResult(requestCode, resultCode, data);
    }
    public void startconfig(){
        apsp1=(Spinner)findViewById(R.id.apsp1);
        apsp2=(Spinner)findViewById(R.id.apsp2);
        reghome=(Button)findViewById(R.id.reghome);
        reghomeet1=(EditText)findViewById(R.id.reghomeet1);
        reghomeet2=(EditText)findViewById(R.id.reghomeet2);
        reghomeet3=(EditText)findViewById(R.id.reghomeet3);
        reghomeet4=(EditText)findViewById(R.id.reghomeet4);
        addpropimages=findViewById(R.id.addpropimages);
        imv1=findViewById(R.id.imv1);
        imv2=findViewById(R.id.imv2);
        imv3=findViewById(R.id.imv3);
        tip1=findViewById(R.id.tip1);
    }
    public void spinner1() {

        {
            list = new ArrayList<String>();
            list1 = new ArrayList<>();
            Cursor c = obj.getData();
            int sidindex = c.getColumnIndex("sid");
            int snameindex = c.getColumnIndex("sname");
            while (c.moveToNext()) {
                list.add(c.getString(snameindex));
                list1.add(c.getString(sidindex));
            }
            ArrayAdapter arrayAdapter = new ArrayAdapter<String>
                    (HostAddPropertyActivity.this, android.R.layout.simple_list_item_1, list);
            apsp1.setAdapter(arrayAdapter);
        }
    }
    public void spinner2(){
        list2 = new ArrayList<String>();
        list3 = new ArrayList<>();
        Cursor c = obj.getcityData();
        int cidindex = c.getColumnIndex("cid");
        int cnameindex = c.getColumnIndex("cname");
        int sidindex1=c.getColumnIndex("sid");
        while (c.moveToNext()) {
            list2.add(c.getString(cnameindex));
            list3.add(c.getString(cidindex));
        }
        ArrayAdapter arrayAdapter = new ArrayAdapter<String>
                (HostAddPropertyActivity.this, android.R.layout.simple_list_item_1, list2);
        apsp2.setAdapter(arrayAdapter);
    }
    public void citybind(){
        list4 = new ArrayList<String>();
        list5 = new ArrayList<>();
        Cursor c = obj.getscitydata(stateid);
        int cidindex = c.getColumnIndex("cid");
        int cnameindex = c.getColumnIndex("cname");
        int sidindex1=c.getColumnIndex("sid");
        while (c.moveToNext()) {
            list4.add(c.getString(cnameindex));
            list5.add(c.getString(cidindex));
        }
        ArrayAdapter arrayAdapter = new ArrayAdapter<String>
                (HostAddPropertyActivity.this, android.R.layout.simple_list_item_1, list4);
        apsp2.setAdapter(arrayAdapter);
    }
    public byte[] imageviewtobyte(ImageView imageView)
    {
        Bitmap bitmap=((BitmapDrawable)imageView.getDrawable()).getBitmap();
        ByteArrayOutputStream stream=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,100,stream);
        byte[] bytearray=stream.toByteArray();
        return bytearray;
    }
    public void showmsg(String s){
        Toast.makeText(this, s.toString(), Toast.LENGTH_SHORT).show();
    }
    private boolean isNullRec(String n)
    {
        if(n!="" && n.length() > 0)
        {
            return true;
        }
        return false;
    }
    private boolean isValidPan(String s){

        Pattern pattern = Pattern.compile("[A-Z]{5}[0-9]{4}[A-Z]{1}");
        Matcher matcher = pattern.matcher(s);
        return matcher.matches();
    }

}
