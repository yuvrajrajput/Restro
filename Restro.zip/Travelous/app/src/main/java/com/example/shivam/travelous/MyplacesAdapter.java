package com.example.shivam.travelous;

import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MyplacesAdapter extends RecyclerView.Adapter<MyplacesAdapter.Myviewholder> {


    private List<Myplaces> aproperty;
    Context context;

    public MyplacesAdapter(List<Myplaces> properties, MyPlacesActivity myPlacesActivity) {
        this.aproperty=properties;
        this.context=myPlacesActivity;
    }

    @NonNull
    @Override
    public Myviewholder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        Context context =viewGroup.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View contactView = inflater.inflate(R.layout.myplacesviewholder,viewGroup, false);
        Myviewholder viewHolder = new Myviewholder(contactView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final Myviewholder myviewholder, final int i) {
        Myplaces property=aproperty.get(i);
        Myplaces property1=aproperty.get(i);
        TextView name=myviewholder.name;
        name.setText(property.getname());
        TextView address=myviewholder.address;
        address.setText(property.getaddress());
        ImageView imageView=myviewholder.imageView;
        imageView.setImageBitmap(BitmapFactory.decodeByteArray(property.getimage(),0,property.getimage().length));
        Button button=myviewholder.del;

        final int hid=property.getid();
        myviewholder.del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DbHelper obj=new DbHelper(context);
                if (obj.deleteplace(hid)){
                    Toast.makeText(context, "Property Deleted!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }



    @Override
    public int getItemCount() {
        return aproperty.size();
    }

    public class Myviewholder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView name;
        public TextView address;
        public ImageView imageView;
        public CardView cardView1;
        public Button del;
        ItemClickListner itemClickListener;
        public Myviewholder(View itemView) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.thomename2);
            address=itemView.findViewById(R.id.thomeaddress2);
            imageView=itemView.findViewById(R.id.thproimage2);
            cardView1=itemView.findViewById(R.id.cardview12);
            del=itemView.findViewById(R.id.del_places);
        }

        @Override
        public void onClick(View v) {
            this.itemClickListener.onItemclick(v,getLayoutPosition());
        }
    }
}
