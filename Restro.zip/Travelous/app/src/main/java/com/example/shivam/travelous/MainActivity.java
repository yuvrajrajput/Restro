package com.example.shivam.travelous;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity {
    Button logbtn;
    EditText uet1,pet2;
    TextView t1,t2;
    DbHelper obj;
    Spinner sp1;
    Integer pos=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        obj = new DbHelper(this);

        config();
        sp1=(Spinner)findViewById(R.id.sp1);
        String[]options={"Hotel Manager","User",};
        ArrayAdapter<String>adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,options);
        sp1.setAdapter(adapter);
        sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                    pos=position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(),RegisterActivity.class);
                startActivity(i);
            }
        });
        t2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i2=new Intent(getApplicationContext(),ForgotpassActivity.class);
                startActivity(i2);
            }
        });

    }

    public void config()
    {
        t2=(TextView)findViewById(R.id.t2);
        t1=(TextView)findViewById(R.id.t1);
        logbtn = (Button)findViewById(R.id.lgbtn1);
        uet1 = (EditText)findViewById(R.id.et1);
        pet2 = (EditText)findViewById(R.id.et2);
    }
    public void showmsg(String msg)
    {
        Toast.makeText(this,msg, Toast.LENGTH_SHORT).show();
    }

    public void login(View view) {
        String semail = uet1.getText().toString();
        String spwd = pet2.getText().toString();
        if (!isNullRec(semail)){
            uet1.setError("Field Can't Be Empty");
        }
        if (!isNullRec(spwd)){
            pet2.setError("Field Can't Be Empty");
        }
        if (isNullRec(semail) && isNullRec(spwd)) {
        Cursor c = obj.AdminLogin(semail, spwd);
        Cursor c1 = obj.Travellerlogin(semail, spwd);
        int valid = c1.getColumnIndex("actstatus");
        int n1=c1.getColumnIndex("tname");
        int validate=0;
        String tname="";
        if (c1.getCount()>0) {
            c1.moveToFirst();
            tname=c1.getString(n1);
            validate = c1.getInt(valid);
        }
        Cursor c2 = obj.Hostlogin(semail, spwd);
        int valid1 = c2.getColumnIndex("actstatus");
        int n=c2.getColumnIndex("hname");
        int validate1=0;
        String hname="";
        if (c2.getCount()>0) {
            c2.moveToFirst();
            hname=c2.getString(n);
            validate1 = c2.getInt(valid1);
        }
        try {
            //admin
            if (pos == 0) {
                if (c.getCount() > 0) {
                    showmsg("Login Successfully");
                    Intent i = new Intent(getApplicationContext(), AHomeActivity.class);
                    startActivity(i);
                    cleartxt();
                    finish();
                } else {
                    pet2.setError("Invalid Email Or Password");
                }
            }



                //traveller
                if (pos == 1) {
                    if (validate == 1) {
                        showmsg("Your Account Has Been Banned!");
                    } else if (c1.getCount() > 0) {
                        showmsg("Login successfully");
                        Intent i = new Intent(getApplicationContext(), ThomeActivity.class);
                        i.putExtra("name", tname);
                        i.putExtra("email", semail);
                        startActivity(i);
                        cleartxt();
                        finish();
                    } else {
                        pet2.setError("Invalid Email Or Password");
                    }


                }

                //host
                if (pos == 2) {
                    if (validate1 == 1) {
                        showmsg("Your Account Has Been Banned!");
                    } else if (c2.getCount() > 0) {
                        showmsg("Login successfully");
                        Intent i = new Intent(getApplicationContext(), HhomeActivity.class);
                        i.putExtra("name", hname);
                        i.putExtra("email", semail);
                        startActivity(i);
                        cleartxt();
                        finish();
                    } else {
                        pet2.setError("Invalid Email Or Password");
                    }

                }
            } catch(Exception ex){

                showmsg(ex.toString());
            }
        }
    }

    public void cleartxt(){
        uet1.setText("");
        pet2.setText("");
    }
    private boolean isNullRec(String n)
    {
        if(n!="" && n.length() > 0)
        {
            return true;
        }
        return false;
    }
}
