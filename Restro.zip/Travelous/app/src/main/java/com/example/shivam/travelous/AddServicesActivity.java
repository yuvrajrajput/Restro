package com.example.shivam.travelous;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class AddServicesActivity extends AppCompatActivity {
EditText ser1,ser2,ser3,amount;
Button addser;
DbHelper obj;
SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_services);
        ser1=findViewById(R.id.ser1);
        ser2=findViewById(R.id.ser2);
        ser3=findViewById(R.id.ser3);
        amount=findViewById(R.id.amount);
        addser=findViewById(R.id.addser);
        obj=new DbHelper(this);
        db=openOrCreateDatabase("Travelous.db",Context.MODE_PRIVATE,null);
        final String pname=getIntent().getStringExtra("pname");
        Cursor c=obj.getpropertyid(pname);
        int id=c.getColumnIndex("pid");

//        final int ids=c.getColumnIndex("pid");
        c.moveToFirst();
        final int i=c.getInt(id);
//        final int id2=c.getInt(ids);
        addser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String service1=ser1.getText().toString();
                String service2=ser2.getText().toString();
                String service3=ser3.getText().toString();
                String amount1=amount.getText().toString();
                int i5=Integer.parseInt(amount1);
                if (obj.addservices(i,service1,service2,service3,i5)){
                    Toast.makeText(AddServicesActivity.this, "Services Added", Toast.LENGTH_SHORT).show();
                }else
                {
                    Toast.makeText(AddServicesActivity.this, "Services Not Added", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
