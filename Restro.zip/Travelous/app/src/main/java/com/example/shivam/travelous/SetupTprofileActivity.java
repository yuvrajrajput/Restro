package com.example.shivam.travelous;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.hdodenhof.circleimageview.CircleImageView;

public class SetupTprofileActivity extends AppCompatActivity {
    Spinner gender,tssp1,tssp2;
    FloatingActionButton fab2;
    EditText taadharet,tpanet;
    CircleImageView tsimgv;
    Button shivam;
    ArrayList<String> list,list1,list2,list3,list4,list5;
    DbHelper obj;
    String tgender;
    final int REQUEST_CODE_GALLERY=999;
    int stateid,cityid,selctedcity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setup_tprofile);
        obj=new DbHelper(this);
        startconfig();
        String[] options1={"--SELECT--","MALE","FEMALE"};
        final String name=getIntent().getStringExtra("name").toString();
        final String email=getIntent().getStringExtra("email").toString();
        final String pwd=getIntent().getStringExtra("pwd").toString();
        final String contact=getIntent().getStringExtra("contact");
        list = new ArrayList<String>();
        list2 = new ArrayList<String>();
        ArrayAdapter ar=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,options1);
        gender.setAdapter(ar);
        spinner1();
        spinner2();
        shivam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String aadhar=taadharet.getText().toString().trim();
                String pancard=tpanet.getText().toString().trim();
                if (!isNullRec(aadhar)){
                    taadharet.setError("Field Can't Be Empty");
                }
                if (!isValidAdhar(aadhar)){
                    taadharet.setError("Enter Valid Aadhar Number");
                }
                if (!isNullRec(pancard)){
                    tpanet.setError("Field Can't Be Empty");
                }
                if (!isValidPan(pancard)){
                    tpanet.setError("Enter A Valid PanCard Number");
                }
                if ((isNullRec(aadhar))&&(isValidPan(pancard))&&(isNullRec(pancard))&&(isValidAdhar(aadhar))) {


                    if (obj.addtraveller(name, email, pwd, contact, aadhar, pancard, stateid, selctedcity, imageviewtobyte(tsimgv), tgender)) {
                        Toast.makeText(SetupTprofileActivity.this, "Registration Successful!!", Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(getApplicationContext(), ThomeActivity.class);
                        i.putExtra("name", name);
                        i.putExtra("email", email);
                        i.putExtra("pwd", pwd);
                        i.putExtra("contact", contact);
                        startActivity(i);
                        finish();
                    } else {
                        Toast.makeText(getApplicationContext(), "Registration Failed!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        gender.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                getgender(position);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        fab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent,REQUEST_CODE_GALLERY);
            }
        });
        tssp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                String m=list1.get(position);
                stateid=Integer.parseInt(m);
                citybind();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        tssp2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String m=list3.get(position);
                cityid=Integer.parseInt(m);
                String s=list4.get(position);
                Cursor c=obj.getonescity(s);
                int c1=c.getColumnIndex("cid");
                c.moveToFirst();
                selctedcity=c.getInt(c1);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        // Check which request it is that we're responding to
        // Make sure the request was successful
        if(requestCode==REQUEST_CODE_GALLERY && resultCode==RESULT_OK && data!=null) {
            // Get the URI that points to the selected contact
            Uri uri = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                tsimgv.setImageBitmap(bitmap);
                showmsg("Image Display");

            } catch (Exception ex) {
                showmsg(ex.getMessage());
            }

        }
        super.onActivityResult(requestCode, resultCode, data);
    }
    public void showmsg(String s){
        Toast.makeText(this, s.toString(), Toast.LENGTH_SHORT).show();
    }
    public void startconfig(){
        tssp1=(Spinner)findViewById(R.id.tssp1);
        tssp2=(Spinner)findViewById(R.id.tssp2);
        gender=(Spinner) findViewById(R.id.gender);
        fab2=findViewById(R.id.tsfab);
        tsimgv=findViewById(R.id.tsimgv);
        taadharet=findViewById(R.id.taadharet);
        tpanet=findViewById(R.id.tpanet);
        shivam=(Button) findViewById(R.id.shivam);
    }
    public void spinner1() {

        {
            list = new ArrayList<String>();
            list1 = new ArrayList<>();
            Cursor c = obj.getData();
            int sidindex = c.getColumnIndex("sid");
            int snameindex = c.getColumnIndex("sname");
            while (c.moveToNext()) {
                list.add(c.getString(snameindex));
                list1.add(c.getString(sidindex));
            }
            ArrayAdapter arrayAdapter = new ArrayAdapter<String>
                    (SetupTprofileActivity.this, android.R.layout.simple_list_item_1, list);
            tssp1.setAdapter(arrayAdapter);
        }
    }
    public void spinner2(){
        list2 = new ArrayList<String>();
        list3 = new ArrayList<>();
        Cursor c = obj.getcityData();
        int cidindex = c.getColumnIndex("cid");
        int cnameindex = c.getColumnIndex("cname");
        int sidindex1=c.getColumnIndex("sid");
        while (c.moveToNext()) {
            list2.add(c.getString(cnameindex));
            list3.add(c.getString(cidindex));
        }
        ArrayAdapter arrayAdapter = new ArrayAdapter<String>
                (SetupTprofileActivity.this, android.R.layout.simple_list_item_1, list2);
        tssp2.setAdapter(arrayAdapter);
    }
    public void citybind(){
        list4 = new ArrayList<String>();
        list5 = new ArrayList<>();
        Cursor c = obj.getscitydata(stateid);
        int cidindex = c.getColumnIndex("cid");
        int cnameindex = c.getColumnIndex("cname");
        int sidindex1=c.getColumnIndex("sid");
        while (c.moveToNext()) {
            list4.add(c.getString(cnameindex));
            list5.add(c.getString(cidindex));
        }
        ArrayAdapter arrayAdapter = new ArrayAdapter<String>
                (SetupTprofileActivity.this, android.R.layout.simple_list_item_1, list4);
        tssp2.setAdapter(arrayAdapter);
    }
    public byte[] imageviewtobyte(ImageView imageView)
    {
        Bitmap bitmap=((BitmapDrawable)imageView.getDrawable()).getBitmap();
        ByteArrayOutputStream stream=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,100,stream);
        byte[] bytearray=stream.toByteArray();
        return bytearray;
    }
    public void getgender(int pos){
        if(pos==0){

        }
        else if (pos==1){
            tgender="MALE";
        }else {
            tgender="FEMALE";
        }
    }
    private boolean isValidAdhar(String adhar){

        if(adhar.length()==12){
            return true;
        }
        return false;
    }

    private boolean isValidPan(String s){

        Pattern pattern = Pattern.compile("[A-Z]{5}[0-9]{4}[A-Z]{1}");
        Matcher matcher = pattern.matcher(s);
        return matcher.matches();
    }
    private boolean isNullRec(String n)
    {
        if(n!="" && n.length() > 0)
        {
            return true;
        }
        return false;
    }
}
