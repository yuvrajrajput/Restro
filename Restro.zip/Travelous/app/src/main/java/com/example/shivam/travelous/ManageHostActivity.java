package com.example.shivam.travelous;

import android.database.Cursor;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;



import java.util.ArrayList;

public class ManageHostActivity extends AppCompatActivity {
    ListView hmulv;
    DbHelper obj;
    int id1,flag;
    CoordinatorLayout hostmanage;
    ArrayList<String> list1,list2,list3,list4;
    EditText htravet1;
    Button htrabtn1,hreftra;
    String hostname;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_host);

        obj=new DbHelper(this);
        startconfig();
        hreftra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listbind();
                flag=1;
            }
        });
        htrabtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hostname=htravet1.getText().toString();
                searchbind();
                if (list4.isEmpty()){
                    htravet1.setError("Host Doesn't Exist");
                }
                flag=0;
            }
        });


        hmulv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String pos;
                if (flag==1){
                    pos=list1.get(position);
                }
                else{
                    pos=list3.get(position);
                }
                int getid=Integer.parseInt(pos);
                id1=Integer.parseInt(pos);
                showsnake();
            }
        });
    }
    public void listbind(){
        list1=new ArrayList<String>();
        list2=new ArrayList<String>();
        Cursor c=obj.gethost();
        int tname=c.getColumnIndex("hname");
        int tid=c.getColumnIndex("hid");
        int statas1=c.getColumnIndex("actstatus");
        int password=c.getColumnIndex("hpwd");
        hmulv.setAdapter(null);
        while (c.moveToNext()){
            int i=c.getInt(c.getColumnIndex("actstatus"));
            if (i == 0) {
                list1.add(c.getString(tid));
                list2.add("ACTIVE  "+"      "+c.getString(tname));
            }else if(i==1)
            {
                list1.add(c.getString(tid));
                list2.add("BANNED"+"      "+c.getString(tname));

            }
        }
        ArrayAdapter arrayAdapter=new ArrayAdapter<String>(ManageHostActivity.this,android.R.layout.simple_list_item_1,list2);
        hmulv.setAdapter(arrayAdapter);
        flag=1;

    }
    public void searchbind() {
        list3 = new ArrayList<String>();
        list4 = new ArrayList<String>();
        Cursor c1 = obj.searchhost(hostname);
        int tname = c1.getColumnIndex("hname");
        int tid = c1.getColumnIndex("hid");
        int statas=c1.getColumnIndex("actstatus");
        hmulv.setAdapter(null);

        while (c1.moveToNext()) {
            int i=c1.getInt(c1.getColumnIndex("actstatus"));
            if (i == 0) {
                list3.add(c1.getString(tid));
                list4.add("ACTIVE  "+"      "+c1.getString(tname));
            }else if(i==1)
            {
                list3.add(c1.getString(tid));
                list4.add("BANNED"+"      "+c1.getString(tname));

            }
        }

        ArrayAdapter arrayAdapter1 = new ArrayAdapter<String>(ManageHostActivity.this, android.R.layout.simple_list_item_1, list4);
        hmulv.setAdapter(arrayAdapter1);
        flag=0;

    }
    public  void showsnake() {
        Cursor c5=obj.getonehost(id1);
        String button;
        int sid=c5.getColumnIndex("actstatus");
        c5.moveToFirst();
        int data=c5.getInt(sid);
        if (data==0){
            button="Disable";
        }else {
            button="Enable";
        }
        final Snackbar snackbar = Snackbar.make(hostmanage, "Change Account Status?", Snackbar.LENGTH_INDEFINITE).setAction(button, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changestatus();
                Snackbar snackbar1 = Snackbar.make(hostmanage, "Account Status Changed Successfully!!!", Snackbar.LENGTH_SHORT);
                snackbar1.show();
                if (flag==0){
                    searchbind();
                }
                else if (flag==1){
                    listbind();
                }else {

                }
            }
        });
        snackbar.show();
    }
    public void startconfig(){
        htravet1=(EditText)findViewById(R.id.htravet1);
        htrabtn1=(Button)findViewById(R.id.hsearch);
        hmulv=(ListView)findViewById(R.id.hmulv);
        hostmanage=(CoordinatorLayout) findViewById(R.id.hostmanage);
        hreftra=(Button)findViewById(R.id.hreftra);
    }
    public void changestatus(){
        Cursor c=obj.getonehost(id1);
        int tid=c.getColumnIndex("hid");
        int sid=c.getColumnIndex("actstatus");
        c.moveToFirst();
        int data=c.getInt(sid);
        if (data==0) {
            if (obj.banaccounthost(id1,1)) {
                Toast.makeText(this, "Account Banned!!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Operation Failed", Toast.LENGTH_SHORT).show();
            }
        }else{
            if (obj.banaccounthost(id1, 0)) {
                Toast.makeText(this, "Account Activated!!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Operation Failed", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
