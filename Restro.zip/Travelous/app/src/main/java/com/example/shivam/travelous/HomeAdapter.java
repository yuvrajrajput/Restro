package com.example.shivam.travelous;

import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class HomeAdapter extends RecyclerView.Adapter<HomeAdapter.ViewHolder1> {
    private List<Home> aproperty;
    Context context;

    public HomeAdapter(List<Home> home, BrowseHomeActivity browseHomeActivity) {
        this.aproperty = home;
        this.context = browseHomeActivity;
    }

    @NonNull
    @Override
    public ViewHolder1 onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        Context context =viewGroup.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View contactView = inflater.inflate(R.layout.property_viewholder,viewGroup, false);
        ViewHolder1 viewHolder1=new ViewHolder1(contactView);
        return viewHolder1;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder1 viewHolder1, int i) {
        Home property=aproperty.get(i);
        Home property1=aproperty.get(i);
        TextView name=viewHolder1.name;
        name.setText(property.getname());
        TextView address=viewHolder1.address;
        address.setText(property.getaddress());
        ImageView imageView=viewHolder1.imageView;
        TextView ratings=viewHolder1.thomerating;
        ratings.setText(Integer.toString(property.getid()));
        imageView.setImageBitmap(BitmapFactory.decodeByteArray(property.getimage(),0,property.getimage().length));
        final String s1=Integer.toString(property.getid());
        final String name1=property.getname();
        final String address1=property.getaddress();
        final String tname=property.gettname();
        final String temail=property.gettemail();
        viewHolder1.cardView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(context,BrowsePropertyActivity.class);
                i.putExtra("pname",name1);
                i.putExtra("id",s1);
                i.putExtra("address",address1);
                i.putExtra("tname",tname);
                i.putExtra("temail",temail);
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return aproperty.size();
    }

    public class ViewHolder1 extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView name;
        public TextView address;
        public ImageView imageView;
        public CardView cardView1;
        public TextView thomerating;
        ItemClickListner itemClickListener;

        public ViewHolder1(final View itemView) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.thomename);
            address = itemView.findViewById(R.id.thomeaddress);
            imageView = itemView.findViewById(R.id.thproimage);
            cardView1 = itemView.findViewById(R.id.cardview1);
            thomerating = itemView.findViewById(R.id.thomeratings);
            /*itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });*/
        }

        @Override
        public void onClick(View v) {

        }
    }
}