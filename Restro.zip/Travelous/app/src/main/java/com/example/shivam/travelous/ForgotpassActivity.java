package com.example.shivam.travelous;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import java.util.Random;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class ForgotpassActivity extends AppCompatActivity {
EditText fhet1,fhet2,fhet3,fhet4,fhet5,enternewpass;
Button confotp,sendotp;
Spinner spinner2;
DbHelper obj;
int otp;
int posi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgotpass);
        obj=new DbHelper(this);
    fhet1=(EditText)findViewById(R.id.fhet1);
        fhet2=(EditText)findViewById(R.id.fhet2);
        fhet3=(EditText)findViewById(R.id.fhet3);
        fhet4=(EditText)findViewById(R.id.fhet4);
        fhet5=(EditText)findViewById(R.id.fhet5);
    sendotp=(Button)findViewById(R.id.sendforgot);
    enternewpass=findViewById(R.id.enternewpass);
    confotp=findViewById(R.id.changepass);
    confotp.setEnabled(false);
    spinner2=findViewById(R.id.spinner2);

    String[]opt={"Host","Traveller"};
        ArrayAdapter<String> arrayAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,opt);
        spinner2.setAdapter(arrayAdapter);
    spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            posi=position;
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    });

        sendotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number=fhet1.getText().toString();
                otp= random();
                //Toast.makeText(ConfirmOTPActivity.this, , Toast.LENGTH_SHORT).show();
                String msg = "Your OTP : " + otp;
                try
                {
                    SmsManager smsManager=SmsManager.getDefault();
                    smsManager.sendTextMessage(number,null,msg,null,null);

                }
                catch (Exception ex)
                {
                    showmsg(ex.getMessage());
                }

                sendotp.setEnabled(false);
                confotp.setEnabled(true);
                Timer buttonTimer = new Timer();
                buttonTimer.schedule(new TimerTask() {

                    @Override
                    public void run() {
                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                sendotp.setEnabled(true);
                            }
                        });
                    }
                }, 30000);
            }
        });
        confotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String host="host";
                String pass=enternewpass.getText().toString();
                String traveller="traveller";
                String number =fhet1.getText().toString();
                int char1=0;
                int char2=0;
                int char3=0;
                int char4=0;
                //String getotp=conet2.getText().toString();
                //int otp1=Integer.parseInt(getotp);
                String get1otp=fhet2.getText().toString().trim();
                char1=!get1otp.equals("")?Integer.parseInt(get1otp):0;
                String get2otp=fhet3.getText().toString().trim();
                char2=!get1otp.equals("")?Integer.parseInt(get2otp):0;
                String get3otp=fhet4.getText().toString().trim();
                char3=!get1otp.equals("")?Integer.parseInt(get3otp):0;
                String get4otp=fhet5.getText().toString().trim();
                char4=!get1otp.equals("")?Integer.parseInt(get4otp):0;
                int full=((char1*1000)+(char2*100)+(char3*10)+char4);
                if (!isNullRec(enternewpass.getText().toString())){
                    enternewpass.setError("Field Can't Be Empty");
                }
                if ((isNullRec(enternewpass.getText().toString()))) {
                    if (posi == 0) {
                        if (obj.changemobile(fhet1.getText().toString(), pass)) {
                            Toast.makeText(ForgotpassActivity.this, "Password Changed Successfully!", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(ForgotpassActivity.this, "Invalid OTP OR Number", Toast.LENGTH_SHORT).show();
                        }
                    }
                    if (posi == 1) {
                        if (obj.changemobile1(fhet1.getText().toString(), pass)) {
                            Toast.makeText(ForgotpassActivity.this, "Password Changed Successfully!", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(ForgotpassActivity.this, "Invalid OTP OR Number", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
        fhet2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length()==1)
                {
                    fhet3.requestFocus();
                }
                else if(s.length()==0)
                {

                }
            }
        });
        fhet3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length()==1)
                {
                    fhet4.requestFocus();
                }
                else if(s.length()==0)
                {
                    fhet2.requestFocus();
                }
            }
        });
        fhet4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length()==1)
                {
                    fhet5.requestFocus();
                }
                else if(s.length()==0)
                {
                    fhet3.requestFocus();
                }
            }
        });
        fhet5.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length()==1)
                {
                    fhet5.clearFocus();
                }
                else if(s.length()==0)
                {
                    fhet4.requestFocus();
                }
            }
        });


    }
    public int random()
    {
        int v;
        Random r=new Random();
        v=r.nextInt(9999);
        return  v;
    }
    public void showmsg(String msg)
    {
        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
    }
    private boolean isNullRec(String n)
    {
        if(n!="" && n.length() > 0)
        {
            return true;
        }
        return false;
    }
}
