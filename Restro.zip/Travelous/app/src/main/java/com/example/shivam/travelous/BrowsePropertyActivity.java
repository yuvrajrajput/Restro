package com.example.shivam.travelous;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import de.hdodenhof.circleimageview.CircleImageView;

public class BrowsePropertyActivity extends AppCompatActivity {
CardView bpbook;
TextView bppname,bppaddress;
DbHelper obj;
ImageView iv1,iv2,iv3;
TextView bpptv1,bpptv2,bpptv3,bpptv11,bpptv22,bpptv33,hnamebp,pricebp;
CircleImageView himagebp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browse_property);
        bpbook=findViewById(R.id.bpbook);
        pricebp=findViewById(R.id.pricebp);
        startconfig();
        obj=new DbHelper(this);
        final String name=getIntent().getStringExtra("pname");
        String address=getIntent().getStringExtra("address");
        final String tname=getIntent().getStringExtra("tname");
        final String temail=getIntent().getStringExtra("temail");
        String id=getIntent().getStringExtra("id");
        int id1=Integer.parseInt(id);
        bppname.setText(name);
        bppaddress.setText(address);
        Cursor c=obj.getpropertyid(name);
        c.moveToFirst();
        int hid=c.getInt(c.getColumnIndex("hid"));
        final int amount=c.getInt(c.getColumnIndex("amount"));
        byte[] image1=c.getBlob(c.getColumnIndex("proimage1"));
        byte[] image2=c.getBlob(c.getColumnIndex("proimage2"));
        byte[] image3=c.getBlob(c.getColumnIndex("proimage3"));
        String ser1=c.getString(c.getColumnIndex("service1"));
        String ser2=c.getString(c.getColumnIndex("service2"));
        String ser3=c.getString(c.getColumnIndex("service3"));
        Cursor c1=obj.getonehost(hid);
        c1.moveToFirst();
        pricebp.setText("Price:"+amount);
        String hname=c1.getString(c1.getColumnIndex("hname"));
        byte[] himage=c1.getBlob(c1.getColumnIndex("hpic"));
        if (image1!=null){
            iv1.setImageBitmap(BitmapFactory.decodeByteArray(image1,0,image1.length));
        }
        else {
            iv1.setVisibility(View.GONE);
        }
        if (image2!=null){
            iv2.setImageBitmap(BitmapFactory.decodeByteArray(image2,0,image2.length));
        }
        else {
            iv2.setVisibility(View.GONE);
        }
        if (image3!=null){
            iv3.setImageBitmap(BitmapFactory.decodeByteArray(image3,0,image3.length));
        }
        else {
            iv3.setVisibility(View.GONE);
        }
        if (ser1!=null){
            bpptv1.setText(ser1);
        }
        else {
            bpptv1.setText("-");
        }
        if (ser2!=null){
            bpptv2.setText(ser2);
        }
        else{
            bpptv2.setText("-");
        }
        if (ser3!=null){
            bpptv3.setText(ser3);
        }
        else{
            bpptv3.setText("-");
        }
        if (hname!=null){
            hnamebp.setText(hname);
        }
        if (himage!=null){
            himagebp.setImageBitmap(BitmapFactory.decodeByteArray(himage,0,himage.length));
        }
        else
        {
            himagebp.setVisibility(View.GONE);
        }
//        Cursor c11=obj.gettravellerid(tname,temail);
//        c11.moveToFirst();
//        int traname=c11.getInt(c.getColumnIndex("tid"));
        bpbook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String amount2=Integer.toString(amount);
                Intent i=new Intent(getApplicationContext(),SelectDateActivity.class);
                i.putExtra("pname",name);
                i.putExtra("tname",tname);
                i.putExtra("temail",temail);
                i.putExtra("amount",amount2);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                finish();
            }
        });
    }
    public void startconfig(){
        bppname =findViewById(R.id.bppname);
        bppaddress=findViewById(R.id.bppaddress);
        iv1=findViewById(R.id.bppimv1);
        iv2=findViewById(R.id.bppimv2);
        iv3=findViewById(R.id.bppimv3);
        bpptv1=findViewById(R.id.bpptv1);
        bpptv2=findViewById(R.id.bpptv2);
        bpptv3=findViewById(R.id.bpptv3);
        bpptv11=findViewById(R.id.bpptv11);
        bpptv22=findViewById(R.id.bpptv22);
        bpptv33=findViewById(R.id.bpptv33);
        hnamebp=findViewById(R.id.hnamebp);
        himagebp=findViewById(R.id.himagebp);
    }
}
