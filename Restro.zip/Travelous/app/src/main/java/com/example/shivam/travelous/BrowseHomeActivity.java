package com.example.shivam.travelous;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class BrowseHomeActivity extends AppCompatActivity {
RecyclerView bhrv;
    DbHelper obj;
    Spinner bhsp1,bhsp2;
    int stateid,cityid,selectedcity;
    ArrayList<String>list,list1,list2,list3,list4,list5;
    CardView tab1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browse_home);
        tab1 = findViewById( R.id.tab1 );
        tab1.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),Pizza.class);
                startActivity( i );
            }
        } );

        obj = new DbHelper(this);
        spinner1();
        spinner2();
        Cursor d = obj.gethome();
        int propertyname = d.getColumnIndex("pname");
        int propertyaddress = d.getColumnIndex("paddress");
        int proimage = d.getColumnIndex("proimage1");
        int pid = d.getColumnIndex("pid");

        final String tname = getIntent().getStringExtra("tname");
        final String temail = getIntent().getStringExtra("temail");

        List<Home> home = new ArrayList<>();
        int i = 0;
        if (d.getCount() != 0) {
            while (d.moveToNext()) {
                Home property1 = new Home(d.getString(propertyname), d.getString(propertyaddress), d.getInt(pid), d.getBlob(proimage), tname, temail);
                home.add(i, property1);
                i++;
            }
            HomeAdapter adapter = new HomeAdapter(home, this);
            bhrv.setAdapter(adapter);
            bhrv.setLayoutManager((new LinearLayoutManager(this)));
        } else {
            Toast.makeText(BrowseHomeActivity.this, "There is no data to show!", Toast.LENGTH_LONG).show();
        }

        bhsp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String m = list1.get(position);
                stateid = Integer.parseInt(m);
                citybind();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        bhsp2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String m = list3.get(position);
                cityid = Integer.parseInt(m);
                String s = list4.get(position);
                Cursor c = obj.getonescity(s);
                int c1 = c.getColumnIndex("cid");
                c.moveToFirst();
                selectedcity = c.getInt(c1);
                recyclerviewbind();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }
            public void spinner1() {

                {
                    list = new ArrayList<String>();
                    list1 = new ArrayList<>();
                    Cursor c = obj.getData();
                    int sidindex = c.getColumnIndex("sid");
                    int snameindex = c.getColumnIndex("sname");
                    while (c.moveToNext()) {
                        list.add(c.getString(snameindex));
                        list1.add(c.getString(sidindex));
                    }
                    ArrayAdapter arrayAdapter = new ArrayAdapter<String>
                            (BrowseHomeActivity.this, android.R.layout.simple_list_item_1, list);
                    bhsp1.setAdapter(arrayAdapter);
                }
            }

            public void spinner2() {
                list2 = new ArrayList<String>();
                list3 = new ArrayList<>();
                Cursor c = obj.getcityData();
                int cidindex = c.getColumnIndex("cid");
                int cnameindex = c.getColumnIndex("cname");
                int sidindex1 = c.getColumnIndex("sid");
                while (c.moveToNext()) {
                    list2.add(c.getString(cnameindex));
                    list3.add(c.getString(cidindex));
                }
                ArrayAdapter arrayAdapter = new ArrayAdapter<String>
                        (BrowseHomeActivity.this, android.R.layout.simple_list_item_1, list2);
                bhsp2.setAdapter(arrayAdapter);
            }

            public void citybind() {
                list4 = new ArrayList<String>();
                list5 = new ArrayList<>();
                Cursor c = obj.getscitydata(stateid);
                int cidindex = c.getColumnIndex("cid");
                int cnameindex = c.getColumnIndex("cname");
                int sidindex1 = c.getColumnIndex("sid");
                while (c.moveToNext()) {
                    list4.add(c.getString(cnameindex));
                    list5.add(c.getString(cidindex));
                }
                ArrayAdapter arrayAdapter = new ArrayAdapter<String>
                        (BrowseHomeActivity.this, android.R.layout.simple_list_item_1, list4);
                bhsp2.setAdapter(arrayAdapter);
            }
            public void recyclerviewbind(){
                Cursor d1 = obj.getcityhome(selectedcity);
                int propertyname1 = d1.getColumnIndex("pname");
                int propertyaddress1 = d1.getColumnIndex("paddress");
                int proimage1 = d1.getColumnIndex("proimage1");
                int pid1 = d1.getColumnIndex("pid");

                final String tname = getIntent().getStringExtra("tname");
                final String temail = getIntent().getStringExtra("temail");
                bhrv.setAdapter(null);
                List<Home> home = new ArrayList<>();
                int i = 0;
                if (d1.getCount() != 0) {
                    while (d1.moveToNext()) {
                        Home property1 = new Home(d1.getString(propertyname1), d1.getString(propertyaddress1), d1.getInt(pid1), d1.getBlob(proimage1), tname, temail);
                        home.add(i, property1);
                        i++;
                    }
                    HomeAdapter adapter = new HomeAdapter(home, this);
                    bhrv.setAdapter(adapter);
                    bhrv.setLayoutManager((new LinearLayoutManager(this)));
                } else {
                    Toast.makeText(BrowseHomeActivity.this, "There is no data to show!", Toast.LENGTH_LONG).show();
                }
            }
        }



