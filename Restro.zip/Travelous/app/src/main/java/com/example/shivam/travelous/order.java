package com.example.shivam.travelous;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class order extends AppCompatActivity {
    Button button3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_order );
        button3= findViewById( R.id.button3 );
        button3.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText( getApplicationContext(),"Process Start",Toast.LENGTH_LONG ).show();
                Intent i = new Intent(getApplicationContext(),PaymentActivity.class);
                startActivity( i );
            }
        } );
    }
}