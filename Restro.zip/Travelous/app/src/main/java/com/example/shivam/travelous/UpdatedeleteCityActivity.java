package com.example.shivam.travelous;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdatedeleteCityActivity extends AppCompatActivity {
    EditText cuet1;
    Button cubtn1,cdbtn1;
    DbHelper obj;
    String city="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_updatedelete_city);
        obj = new DbHelper(this);
        startConfig();

        city=getIntent().getStringExtra("efgh").toString();

        int cid = Integer.parseInt(city);
        try {

            final Cursor c = obj.selectcity(cid);
            int cidindex = c.getColumnIndex("cid");
            int cnameindex = c.getColumnIndex("cname");
            while (c.moveToNext()) {
                cuet1.setText(c.getString(cnameindex));
            }
            cubtn1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int cid = Integer.parseInt(city);
                    String cname = cuet1.getText().toString();
                    if (obj.updatecity(cid, cname)) {
                        Intent i = new Intent(UpdatedeleteCityActivity.this, UpdateCityActivity.class);
                        startActivity(i);
                        finish();
                    } else {
                        showmsg("Record Not Updated");
                    }
                }
            });

        }
        catch (Exception E){
            Toast.makeText(this, E.toString(), Toast.LENGTH_SHORT).show();
        }

        cdbtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int cid = Integer.parseInt(city);
                if(obj.deletecity(cid)){
                    Intent i = new Intent(UpdatedeleteCityActivity.this, UpdateCityActivity.class);
                    startActivity(i);
                    finish();
                }
            }
        });

    }
    public void startConfig()
    {
        cuet1= (EditText)findViewById(R.id.cuet1);
        cubtn1 = (Button)findViewById(R.id.cubtn1);
        cdbtn1=(Button)findViewById(R.id.cdbtn1);

    }
    public void showmsg(String msg)
    {
        Toast.makeText(this,msg, Toast.LENGTH_SHORT).show();
    }

}