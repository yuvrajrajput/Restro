package com.example.shivam.travelous;

public class Myplaces {
    private String name;
    private String address;
    byte[] image1;
    int id;

    public Myplaces(String pname,String address1,int id,byte[] image){
        name=pname;
        address=address1;
        image1=image;
        this.id=id;

    }


    public String getname(){return name;}
    public String getaddress(){return address;}
    public byte[] getimage(){return image1;}
    public int getid(){
        return id;
    }
}
