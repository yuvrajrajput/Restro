package com.example.shivam.travelous;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.*;
import android.telephony.SmsManager;
import android.view.View;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class ConfirmOTPActivity extends AppCompatActivity {
Button sendotp,conotp;
EditText conet1,conet2,co1,co2,co3,co4;
DbHelper obj;
int otp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_otp);

        startconfig();
        obj=new DbHelper(this);
        final String name=getIntent().getStringExtra("name").toString();
        final String email=getIntent().getStringExtra("email").toString();
        final String pwd=getIntent().getStringExtra("pwd").toString();
        final String contact=getIntent().getStringExtra("contact").toString();
        final String dd=getIntent().getStringExtra("regas").toString();
        final String number=contact;
        conet1.setText(contact);
        conotp.setEnabled(false);
        sendotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (obj.enterotp(number,otp)){
                    otp= random();
                    //Toast.makeText(ConfirmOTPActivity.this, , Toast.LENGTH_SHORT).show();
                    String msg = "Your OTP : " + otp;
                    try
                    {
                        SmsManager smsManager=SmsManager.getDefault();
                        smsManager.sendTextMessage(number,null,msg,null,null);

                    }
                    catch (Exception ex)
                    {
                        showmsg(ex.getMessage());
                    }

                    sendotp.setEnabled(false);
                    conotp.setEnabled(true);
                    Timer buttonTimer = new Timer();
                    buttonTimer.schedule(new TimerTask() {

                        @Override
                        public void run() {
                            runOnUiThread(new Runnable() {

                                @Override
                                public void run() {
                                    sendotp.setEnabled(true);
                                }
                            });
                        }
                    }, 30000);
                }
            }
        });
        co1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length()==1)
                {
                    co2.requestFocus();
                }
                else if(s.length()==0)
                {

                }
            }
        });
        co2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length()==1)
                {
                    co3.requestFocus();
                }
                else if(s.length()==0)
                {
                    co1.requestFocus();
                }
            }
        });
        co3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length()==1)
                {
                    co4.requestFocus();
                }
                else if(s.length()==0)
                {
                    co2.requestFocus();
                }
            }
        });
        co4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length()==1)
                {
                    co4.clearFocus();
                }
                else if(s.length()==0)
                {
                    co3.requestFocus();
                }
            }
        });

        conotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String host="host";
                String traveller="traveller";
                int char1=0;
                int char2=0;
                int char3=0;
                int char4=0;
                //String getotp=conet2.getText().toString();
                //int otp1=Integer.parseInt(getotp);
                String get1otp=co1.getText().toString().trim();
                char1=!get1otp.equals("")?Integer.parseInt(get1otp):0;
                String get2otp=co2.getText().toString().trim();
                char2=!get1otp.equals("")?Integer.parseInt(get2otp):0;
                String get3otp=co3.getText().toString().trim();
                char3=!get1otp.equals("")?Integer.parseInt(get3otp):0;
                String get4otp=co4.getText().toString().trim();
                char4=!get1otp.equals("")?Integer.parseInt(get4otp):0;
                int full=((char1*1000)+(char2*100)+(char3*10)+char4);

                if (dd.equals(host)) {

                    if (full == otp) {
                        showmsg("Contact Number Confirmed");
                        Intent i = new Intent(getApplicationContext(), ThomeActivity.class);
                        i.putExtra("name", name);
                        i.putExtra("email", email);
                        i.putExtra("pwd", pwd);
                        i.putExtra("contact", contact);
                        startActivity(i);
                        finish();
                    } else {
                        showmsg("Invalid OTP");
                    }
                }
                if (dd.equals(traveller)){
                    if (full == otp) {
                        showmsg("Contact Number Confirmed");
                        Intent i = new Intent(getApplicationContext(), ThomeActivity.class);
                        i.putExtra("name", name);
                        i.putExtra("email", email);
                        i.putExtra("pwd", pwd);
                        i.putExtra("contact", contact);
                        startActivity(i);
                        finish();
                    } else {
                        showmsg("Invalid OTP");
                    }
                }





            }
        });
    }

    public void startconfig()
    {
        sendotp = (Button)findViewById(R.id.sendotp);
        conet1 = (EditText)findViewById(R.id.conet1);
        conotp = (Button) findViewById(R.id.conotp);
        co1=(EditText)findViewById(R.id.co1);
        co2=(EditText)findViewById(R.id.co2);
        co3=(EditText)findViewById(R.id.co3);
        co4=(EditText)findViewById(R.id.co4);
    }
    public int random()
    {
        int v;
        Random r=new Random();
        v=r.nextInt(9999);
        return  v;
    }
    public void showmsg(String msg)
    {
        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
    }
}
