package com.example.shivam.travelous;

import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import de.hdodenhof.circleimageview.CircleImageView;

public class travellerprofileActivity extends AppCompatActivity {
    CircleImageView iv1;
    TextView tv1,tv2,tv3,tv4,tv5;
    DbHelper obj;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_travellerprofile);
        String name=getIntent().getStringExtra("tname");
        String email=getIntent().getStringExtra("temail");
        startconfig();
        byte[] image2 = new byte[0];
        obj=new DbHelper(this);
        Cursor c=obj.gettravellerid(name,email);
        c.moveToFirst();
        int image1=c.getColumnIndex("tpic");

        int state=c.getColumnIndex("sid");
        int city=c.getColumnIndex("cid");
        image2=c.getBlob(image1);
        if (image2!=null){
            iv1.setImageBitmap(BitmapFactory.decodeByteArray(image2,0,image2.length));

        }
        tv1.setText(name);
        tv2.setText(email);
        c.moveToFirst();
        int sid=c.getInt(state);
        int cid=c.getInt(city);
        Cursor c1=obj.getstatename(sid);
        Cursor c2=obj.getcityname(cid);
        c1.moveToFirst();
        c2.moveToFirst();
        String sname=c1.getString(c1.getColumnIndex("sname"));
        String cname=c2.getString(c2.getColumnIndex("cname"));
        tv3.setText(sname);
        tv4.setText(cname);

        String Cno=c.getString(c.getColumnIndex("tcontact"));
        tv5.setText(Cno);

    }

    public void startconfig()
    {
        iv1=(CircleImageView)findViewById(R.id.iv11);
        tv1=(TextView)findViewById(R.id.tv11);
        tv2=(TextView)findViewById(R.id.tv21);
        tv3=(TextView)findViewById(R.id.tv31);
        tv4=(TextView)findViewById(R.id.tv41);
        tv5=(TextView)findViewById(R.id.tv51);
    }
    }
