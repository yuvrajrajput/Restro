package com.example.shivam.travelous;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateStateActivity extends AppCompatActivity {
    EditText uset1;
    Button usbtn1,usbtn2;
    DbHelper obj;
    String state="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_state);
        obj=new DbHelper(this);
        startconfig();
        state=getIntent().getStringExtra("abcd").toString();
        final int sid=Integer.parseInt(state);
        Cursor c= obj.selectstate(sid);
        int sidindex=c.getColumnIndex("sid");
        int snameindex=c.getColumnIndex("sname");
        while (c.moveToNext())
        {
            uset1.setText(c.getString(snameindex));
        }
        usbtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int sid = Integer.parseInt(state);
                String sname = uset1.getText().toString();

                if(obj.updatestate(sid,sname))
                {
                    Intent i = new Intent(getApplicationContext(),UpdateDeleteActivity.class);
                    startActivity(i);
                    finish();
                }
                else {
                    showmsg("Record not Updated");
                }
            }
        });
        usbtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (obj.deletestate(sid)){
                    showmsg("Record Deleted");
                    Intent i=new Intent(getApplicationContext(),UpdateDeleteActivity.class);
                    startActivity(i);
                    finish();
                }
            }
        });
    }
    public void startconfig(){
        uset1=(EditText)findViewById(R.id.uset1);
        usbtn1=(Button)findViewById(R.id.usbtn1);
        usbtn2=(Button)findViewById(R.id.usbtn2);
    }

    public void showmsg(String msg){
        Toast.makeText(this,msg.toString(), Toast.LENGTH_SHORT).show();
    }
}