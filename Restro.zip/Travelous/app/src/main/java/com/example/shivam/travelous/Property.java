package com.example.shivam.travelous;

public class Property {
    private String name,tname,temail;
    private String address;
    byte[] image1;
    int id;

    public Property(String pname,String address1,int id,byte[] image,String name1,String email1){
        name=pname;
        address=address1;
        image1=image;
        this.id=id;
        tname=name1;
        temail=email1;
    }


    public String getname(){return name;}
    public String getaddress(){return address;}
    public byte[] getimage(){return image1;}
    public int getid(){
        return id;
    }
    public String gettname(){
        return tname;
    }
    public String gettemail(){
        return temail;
    }
}
