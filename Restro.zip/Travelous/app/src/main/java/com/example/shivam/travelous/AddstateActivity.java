package com.example.shivam.travelous;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddstateActivity extends AppCompatActivity {
EditText eset1;
Button esbtn1,esbtn2;
DbHelper obj;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addstate);
        eset1=(EditText)findViewById(R.id.eset1);
        esbtn1=(Button)findViewById(R.id.esbtn1);
        esbtn2=(Button)findViewById(R.id.esbtn2);
        obj=new DbHelper(this);
        esbtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String state = eset1.getText().toString();
                try {
                    if (obj.addstate(state)) {
                        Toast.makeText(AddstateActivity.this, "State Added", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(AddstateActivity.this, "State already exist", Toast.LENGTH_SHORT).show();
                    }
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
        esbtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(),UpdateDeleteActivity.class);
                startActivity(i);
            }
        });
    }
}
