package com.example.shivam.travelous;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.strictmode.SqliteObjectLeakedViolation;
import android.widget.Toast;

public class DbHelper extends SQLiteOpenHelper{
    public DbHelper(Context context) {
        super(context, "Travelous.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE admin_mst(aid INTEGER PRIMARY KEY AUTOINCREMENT, aname varchar(50) UNIQUE, aemail varchar(50) UNIQUE, apwd varchar(50))");
        db.execSQL("INSERT INTO admin_mst(aname,aemail,apwd) VALUES('Hotel Manager','hotelmanager@gmail.com','Hotel123@')");
        db.execSQL("INSERT INTO admin_mst(aname,aemail,apwd) VALUES('','','')");
        db.execSQL("CREATE TABLE traveller_mst(tid INTEGER PRIMARY KEY AUTOINCREMENT,sid INTEGER,cid INTEGER, tname varchar(50) UNIQUE, temail varchar(50) UNIQUE,tcontact varchar(10) UNIQUE,tgender varchar(10),taadhar varchar(20),tpancard varchar(20),tpic BLOB, tpwd varchar(50),actstatus INTEGER DEFAULT 0)");
        db.execSQL("CREATE TABLE state_mst(sid INTEGER PRIMARY KEY AUTOINCREMENT,sname varchar(30) UNIQUE)");
        db.execSQL("CREATE TABLE city_mst(cid INTEGER PRIMARY KEY AUTOINCREMENT,sid INTEGER,cname varchar(30) UNIQUE,FOREIGN KEY (sid) REFERENCES state_mst(sid))");
        db.execSQL("CREATE TABLE host_mst(hid INTEGER PRIMARY KEY AUTOINCREMENT,hpic BLOB,sid INTEGER,cid INTEGER,hname varchar(50) UNIQUE,hemail varchar(50) UNIQUE,hpwd varchar(30),haadharno INTEGER(12) UNIQUE,hcontactno varchar(20),actstatus INTEGER DEFAULT 0,FOREIGN KEY (sid) REFERENCES state_mst(sid),FOREIGN KEY (cid) REFERENCES city_mst(cid))");
        db.execSQL("CREATE TABLE otp(otpid INTEGER PRIMARY KEY AUTOINCREMENT,contactno varchar(20) NOT NUll,genotp INTEGER(10) NOT NULL)");
        db.execSQL("CREATE TABLE property_mst(pid INTEGER PRIMARY KEY AUTOINCREMENT,amount INTEGER(10),hid INTEGER,catid INTEGER,pname varchar(30) UNIQUE,paddress varchar(70),ppincode varchar(10),ppancard varchar(10) UNIQUE,sid INTEGER,service1 varchar(30),service2 varchar(30),proimage1 BLOB,proimage2 BLOB,proimage3 BLOB,service3 varchar(30),rating integer(10) DEFAULT 0,rating_count Integer,feedback varchar(50),cid INTEGER,FOREIGN KEY (sid) REFERENCES state_mst(sid),FOREIGN KEY (cid) REFERENCES city_mst(cid),FOREIGN KEY (hid) REFERENCES host_mst(hid),FOREIGN KEY (catid) REFERENCES category_mst(catid))");
        db.execSQL("CREATE TABLE category_mst(catid INTEGER PRIMARY KEY AUTOINCREMENT,catname varchar(20))");
        db.execSQL("CREATE TABLE booking_mst(bid integer primary key autoincrement,amount varchar(10),hid integer,tid integer,pid integer,indate varchar(20),outdate varchar(20),cardno varchar(20),expmonth varchar(10),expyear varchar(10),nameoncard varchar(20),FOREIGN KEY (tid) references traveller_mst(tid),FOREIGN KEY (hid) references host_mst(hid),FOREIGN KEY (pid) references property_mst(pid))");
        db.execSQL("INSERT INTO category_mst(catname) VALUES ('HOME'),('RESTAURANT')");
        db.execSQL("CREATE Table  message(mid INTEGER PRIMARY KEY AUTOINCREMENT,sendid integer,reciveid integer,message varchar(30),message1 varchar(30))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);
    }

    //Insert traveller
    public boolean addtraveller(String f1, String f2, String f3,String contact,String aadhar,String pancard,int state,int city,byte[] image,String gender)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("tname",f1);
        cv.put("temail",f2);
        cv.put("tpwd",f3);
        cv.put("tcontact",contact);
        cv.put("taadhar",aadhar);
        cv.put("tpancard",pancard);
        cv.put("sid",state);
        cv.put("cid",city);
        cv.put("tpic",image);
        cv.put("tgender",gender);
        long res = db.insert("traveller_mst",null,cv);

        if(res>0)
        {
            return  true;
        }
        return false;
    }
    //add host
    public boolean addhost(String f1, String f2, String f3,String f4,int f5,int f6,String f7,byte[] image)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("hname",f1);
        cv.put("hemail",f2);
        cv.put("hpwd",f3);
        cv.put("hcontactno",f4);
        cv.put("sid",f5);
        cv.put("cid",f6);
        cv.put("haadharno",f7);
        cv.put("hpic",image);
        long res = db.insert("host_mst",null,cv);

        if(res>0)
        {
            return  true;
        }
        return false;
    }
    //add property
    public boolean addproperty1(int hid,int catid,String name,String address,String pincode,String pancard,int sid,int cid,byte[] image){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("hid",hid);
        cv.put("pname",name);
        cv.put("paddress",address);
        cv.put("ppincode",pincode);
        cv.put("ppancard",pancard);
        cv.put("sid",sid);
        cv.put("cid",cid);
        cv.put("proimage1",image);
        cv.put("catid",catid);
        long res = db.insert("property_mst",null,cv);
        if (res>0){
            return true;
        }
        return false;
    }
    public boolean addproperty2(int hid,int catid,String name,String address,String pincode,String pancard,int sid,int cid,byte[] image,byte[] image1){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("hid",hid);
        cv.put("pname",name);
        cv.put("paddress",address);
        cv.put("ppincode",pincode);
        cv.put("ppancard",pancard);
        cv.put("sid",sid);
        cv.put("cid",cid);
        cv.put("proimage1",image);
        cv.put("proimage2",image1);
        cv.put("catid",catid);
        long res = db.insert("property_mst",null,cv);
        if (res>0){
            return true;
        }
        return false;
    }
    public boolean addproperty3(int hid,int catid,String name,String address,String pincode,String pancard,int sid,int cid,byte[] image,byte[] image1,byte[]image2){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("hid",hid);
        cv.put("pname",name);
        cv.put("paddress",address);
        cv.put("ppincode",pincode);
        cv.put("ppancard",pancard);
        cv.put("sid",sid);
        cv.put("cid",cid);
        cv.put("catid",catid);
        cv.put("proimage1",image);
        cv.put("proimage2",image1);
        cv.put("proimage3",image2);
        long res = db.insert("property_mst",null,cv);
        if (res>0){
            return true;
        }
        return false;
    }
    public boolean payment(String amount,int hid,int tid, int pid, String indate, String outdate,String cardno, String expmonth, String expyear, String nameoncard){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("amount",amount);
        cv.put("hid",hid);
        cv.put("tid",tid);
        cv.put("pid",pid);
        cv.put("indate",indate);
        cv.put("outdate",outdate);
        cv.put("cardno",cardno);
        cv.put("expmonth",expmonth);
        cv.put("expyear",expyear);
        cv.put("nameoncard",nameoncard);
        long res=db.insert("booking_mst",null,cv);
        if (res>0){
        return true;
        }
        return false;
    }


    public Cursor showproperty(){
        SQLiteDatabase db=this.getWritableDatabase();
        return db.rawQuery("select * from property_mst",null);
    }
    public Cursor showpropertybyid(int id){
        SQLiteDatabase db=this.getWritableDatabase();
        return db.rawQuery("select * from property_mst where hid="+id,null);
    }
    public Cursor gethome(){
        SQLiteDatabase db=this.getWritableDatabase();
        int id=1;
        return db.rawQuery("select * from property_mst where catid="+id,null);
    }
    public Cursor getcityhome(int id){
        SQLiteDatabase db=this.getWritableDatabase();
        int id2=1;
        return db.rawQuery("select * from property_mst where cid="+id+" and catid="+id2,null);
    }
    public Cursor getrestaurant(){
        SQLiteDatabase db=this.getWritableDatabase();
        int id=2;
        return  db.rawQuery("select * from property_mst where catid="+id,null);

    }
    public Cursor getcityrestaurant(int id){
        SQLiteDatabase db=this.getWritableDatabase();
        int id2=2;
        return db.rawQuery("select * from property_mst where cid="+id+" and catid="+id2,null);
    }
    public boolean addstate(String s1)
    {
        SQLiteDatabase db1=this.getWritableDatabase();
        ContentValues cv1 =new ContentValues();
        cv1.put("sname",s1);
        long res1=db1.insert("state_mst",null,cv1);
        if (res1>0)
        {
            return  true;
        }
            return false;

    }
    //Show

    public Cursor getData() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * from state_mst", null);
    }

    //Login
    public Cursor AdminLogin(String seemail, String sepwd)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM admin_mst WHERE aemail='"+seemail+"' and apwd='"+sepwd+"'",null);
    }
    public Cursor Travellerlogin(String Tr1,String Tr2)
    {
        SQLiteDatabase db1=this.getWritableDatabase();
        return db1.rawQuery("SELECT * FROM traveller_mst WHERE temail='"+Tr1+"' and tpwd='"+Tr2+"'",null);

    }
    public Cursor Hostlogin(String Hr1,String Hr2)
    {
        SQLiteDatabase db1=this.getWritableDatabase();
        return db1.rawQuery("SELECT * FROM host_mst WHERE hemail='"+Hr1+"' and hpwd='"+Hr2+"'",null);

    }
    public boolean addcity(String c1,int c2)
    {
        SQLiteDatabase db2=this.getWritableDatabase();
        ContentValues cv2 =new ContentValues();
        cv2.put("cname",c1);
        cv2.put("sid",c2);
        long res2=db2.insert("city_mst",null,cv2);
        if (res2>0)
        {
            return  true;
        }
        return false;

    }
    public Cursor getcityData() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * from city_mst", null);
    }
    public Cursor gettravellername(String name){
        SQLiteDatabase db=this.getWritableDatabase();
        return db.rawQuery("select * from traveller_mst where tname='"+name+"'",null);
    }
    public Cursor selectcity(int ucid) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM city_mst WHERE cid=" + ucid, null);
    }
    public boolean updatecity(int ucid, String ucname) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("cname",ucname);

        long res = db.update("city_mst",contentValues,"cid" +"=?", new String[]{String.valueOf(ucid)});
        if (res > 0)
        {
            return true;
        }
        return false;
    }
    public boolean addservices(int id,String ser1,String ser2,String ser3,int amount) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("service1", ser1);
        cv.put("service2", ser2);
        cv.put("service3", ser3);
        cv.put("amount",amount);
        long res=db.update("property_mst",cv,"pid"+"=?",new String[]{String.valueOf(id)});
        if (res > 0)
        {
            return true;
        }
        return false;
    }
    public boolean deletecity(int ucid)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        long res = db.delete("city_mst","cid"+"=?",new String[]{String.valueOf(ucid)});
        if(res>0)
        {
            return true;
        }
        return false;
    }
    public boolean deleteplace(int ucid)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        long res = db.delete("property_mst","pid"+"=?",new String[]{String.valueOf(ucid)});
        if(res>0)
        {
            return true;
        }
        return false;
    }
    public Cursor selectstate(int sid){
        SQLiteDatabase db=this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM state_mst WHERE sid="+sid,null);
    }
    public boolean updatestate(int sid, String sname) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("sname", sname);

        long res = db.update("state_mst", contentValues, "sid" + "=?", new String[]{String.valueOf(sid)});
        if (res > 0)
        {
            return true;
        }
        return false;
    }
    public boolean deletestate(int sid) {
        SQLiteDatabase db = this.getWritableDatabase();
        long res = db.delete("state_mst", "sid" + "=?", new String[]{String.valueOf(sid)});
        if(res>0)
        {
            return true;
        }
        return false;
    }
    public Cursor searchtraveller(String s1){

        SQLiteDatabase db=this.getWritableDatabase();
        Cursor c= db.rawQuery("select * from traveller_mst where tname='"+s1+"'",null);
        return c;
    }
    public Cursor searchtravelleremail(String s1){

        SQLiteDatabase db=this.getWritableDatabase();
        Cursor c= db.rawQuery("select * from traveller_mst where temail='"+s1+"'",null);
        return c;
    }
    public boolean banaccount(int tid,int status) {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv =new ContentValues();
        cv.put("actstatus",status);
        long res=db.update("traveller_mst",cv,"tid="+"=?", new String[]{String.valueOf(tid)});
        if (res>0)
        {
            return true;
        }
        return false;
    }
    public Cursor getonetravelller(int t1){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM traveller_mst WHERE tid=" + t1, null);
    }

    public Cursor gettraveller() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM traveller_mst", null);
    }
    public Cursor searchhost(String s1){

        SQLiteDatabase db=this.getWritableDatabase();
        Cursor c= db.rawQuery("select * from host_mst where hname='"+s1+"'",null);
        return c;
    }
    public boolean banaccounthost(int tid,int status) {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv =new ContentValues();
        cv.put("actstatus",status);
        long res=db.update("host_mst",cv,"hid="+"=?", new String[]{String.valueOf(tid)});
        if (res>0)
        {
            return true;
        }
        return false;
    }
    public Cursor getonehost(int t1){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM host_mst WHERE hid=" + t1, null);
    }
    public Cursor gethostid(String name,String email){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM host_mst WHERE hname='" + name+"' AND hemail='"+email+"'", null);
    }
    public Cursor getpropertyid(String name){
        SQLiteDatabase db=this.getWritableDatabase();
        return db.rawQuery("select * from property_mst where pname='"+name+"'",null);
    }
    public Cursor gettravellerid(String name,String email){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM traveller_mst WHERE tname='" + name+"' AND temail='"+email+"'", null);
    }

    public Cursor gethost() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM host_mst", null);
    }
    public Cursor getscitydata(int id){
        SQLiteDatabase db =this.getWritableDatabase();
        return db.rawQuery("select * from city_mst where sid="+id,null);
    }
    public boolean changemobile(String Number,String Password){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("hpwd",Password);
        long res=db.update("host_mst",cv,"hcontactno="+"=?", new String[]{String.valueOf(Number)});
        if (res>0){
            return true;
        }
        return false;
    }
    public boolean changemobile1(String Number,String Password){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("tpwd",Password);
        long res=db.update("traveller_mst",cv,"tcontact="+"=?", new String[]{String.valueOf(Number)});
        if (res>0){
            return true;
        }
        return false;
    }
    public Cursor getonescity(String name){
        SQLiteDatabase db=this.getWritableDatabase();
        return db.rawQuery("select * from city_mst where cname='"+name+"'",null);
    }
    public Cursor confirmotp(String otp,int otp1){
        SQLiteDatabase db=this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM otp WHERE contactno='"+otp+"' and genotp='"+otp1+"'",null);
    }
    public Boolean enterotp(String no,int otp){
        SQLiteDatabase db=getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("contactno",no);
        cv.put("genotp",otp);
        long res2=db.insert("otp",null,cv);
        if (res2>0)
        {
            return  true;
        }
        return false;
    }
    public Cursor getstatename(int id){
        SQLiteDatabase db=this.getWritableDatabase();
        return db.rawQuery("Select * from state_mst where sid="+id,null);
    }
    public Cursor getcityname(int id){
        SQLiteDatabase db=this.getWritableDatabase();
        return db.rawQuery("Select * from city_mst where cid="+id,null);
    }
}
