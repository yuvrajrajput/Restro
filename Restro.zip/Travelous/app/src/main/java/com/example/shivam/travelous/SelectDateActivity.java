package com.example.shivam.travelous;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.*;
import java.util.Calendar;

public class SelectDateActivity extends AppCompatActivity {
    EditText editdate,editdate1;
    Button selectdate,selectdate1;
    TextView tprice;
    CardView proceedtopay;
    private int mYear,mMonth,mDay;
    int checkindate;
    int checkoutdate;
    int checkamount,flag;
    int tamount;
    int m1,m2,d1,d2;
    TextInputLayout date1,date2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_date);
        editdate=findViewById(R.id.editdate);
        selectdate=findViewById(R.id.selectdate);
        editdate1=findViewById(R.id.editdate1);
        selectdate1=findViewById(R.id.selectdate1);
        tprice=findViewById(R.id.tprice);
        proceedtopay=findViewById(R.id.proceedtopay);
        date1=findViewById(R.id.date1);
        date2=findViewById(R.id.date2);
        //get intent
        final String pname=getIntent().getStringExtra("pname");
        final String tname=getIntent().getStringExtra("tname");
        final String temail=getIntent().getStringExtra("temail");
        final String amount=getIntent().getStringExtra("amount");
        proceedtopay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mount=Integer.toString(tamount);
                if (!checking(d1,d2,m1,m2)){
                    date2.setError("Select A valid Checkout Date");
                }
                if (!isNullRec(editdate.getText().toString())){
                    date1.setError("Select CheckIn Date");
                }
                if (!isNullRec(editdate1.getText().toString())){
                    date2.setError("Select CheckOut Date");
                }
                if ((isNullRec(editdate.getText().toString())) && (isNullRec(editdate1.getText().toString())) && (checking(d1,d2,m1,m2)))
                {
                    Intent i = new Intent(getApplicationContext(), PaymentActivity.class);
                    String indate = editdate.getText().toString();
                    String outdate = editdate1.getText().toString();
                    i.putExtra("tname", tname);
                    i.putExtra("temail", temail);
                    i.putExtra("pname", pname);
                    i.putExtra("amount", mount);
                    i.putExtra("indate", indate);
                    i.putExtra("outdate", outdate);
                    startActivity(i);
                    finish();
                }
            }
        });
        selectdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);
                Calendar c1=Calendar.getInstance();
                int inyear=c1.get(Calendar.YEAR);
                int inmmonth =c1.get(Calendar.MONTH);
                int day=c1.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog;
                datePickerDialog = new DatePickerDialog(SelectDateActivity.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {

                                editdate.setText(dayOfMonth + "-" + (monthOfYear + 1 ) + "-" + year);
                                checkindate=dayOfMonth;
                                d1=dayOfMonth;
                                m1=monthOfYear;
                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
                datePickerDialog.show();
            }
        });
        selectdate1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);
                date2.setError(null);
                DatePickerDialog datePickerDialog;
                datePickerDialog = new DatePickerDialog(SelectDateActivity.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                editdate1.setText(dayOfMonth + "-" + (monthOfYear + 1 ) + "-" + year);
                                checkoutdate=dayOfMonth;
                                d2=dayOfMonth;
                                m2=monthOfYear;
                                flag=0;
                                for (int f=checkindate;f<=checkoutdate;f++){
                                    flag++;
                                }
                                tamount=0;
                                tamount=Integer.parseInt(amount);
                                tamount=(tamount*flag);
                                tprice.setText("Total Amount: "+Integer.toString(tamount));
                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
                datePickerDialog.show();
            }
        });
    }
    public boolean checking(int date1,int date2,int month1,int month2){
        if (month2>=month1 && date2>=date1){
            return true;
        }
        return false;
    }
    private boolean isNullRec(String n)
    {
        if(n!="" && n.length() > 0)
        {
            return true;
        }
        return false;
    }
}
