package com.example.shivam.travelous;

import android.database.Cursor;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import java.util.ArrayList;

public class ManageTravellerActivity extends AppCompatActivity {
    ListView mulv;
    DbHelper obj;
    int id1,flag;
    CoordinatorLayout clayout;
    ArrayList<String> list1,list2,list3,list4;
    EditText travet1;
    Button trabtn1,reftra;
    String travellername;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_traveller);

        obj=new DbHelper(this);
        startconfig();
        reftra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listbind();
                flag=1;
            }
        });
        trabtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                travellername=travet1.getText().toString();
                searchbind();
                if (list4.isEmpty()){
                    travet1.setError("Traveller Doesn't Exist");
                }
                flag=0;
            }
        });


        mulv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String pos;
                if (flag==1){
                    pos=list1.get(position);
                }
                else{
                    pos=list3.get(position);
                }
                int getid=Integer.parseInt(pos);
                id1=Integer.parseInt(pos);
                showsnake();
            }
        });
    }
    public void listbind(){
        list1=new ArrayList<String>();
        list2=new ArrayList<String>();
        Cursor c=obj.gettraveller();
        int tname=c.getColumnIndex("tname");
        int tid=c.getColumnIndex("tid");
        int statas1=c.getColumnIndex("actstatus");
        int password=c.getColumnIndex("tpwd");
        mulv.setAdapter(null);
        while (c.moveToNext()){
            int i=c.getInt(c.getColumnIndex("actstatus"));
            if (i == 0) {
                list1.add(c.getString(tid));
                list2.add("ACTIVE  "+"      "+c.getString(tname));
            }else if(i==1)
            {
                list1.add(c.getString(tid));
                list2.add("BANNED"+"      "+c.getString(tname));

            }
        }
        ArrayAdapter arrayAdapter=new ArrayAdapter<String>(ManageTravellerActivity.this,android.R.layout.simple_list_item_1,list2);
        mulv.setAdapter(arrayAdapter);
        flag=1;

    }
    public void searchbind() {
        list3 = new ArrayList<String>();
        list4 = new ArrayList<String>();
        Cursor c1 = obj.searchtraveller(travellername);
        int tname = c1.getColumnIndex("tname");
        int tid = c1.getColumnIndex("tid");
        int statas=c1.getColumnIndex("actstatus");
        mulv.setAdapter(null);

        while (c1.moveToNext()) {
            int i=c1.getInt(c1.getColumnIndex("actstatus"));
            if (i == 0) {
                list3.add(c1.getString(tid));
                list4.add("ACTIVE  "+"      "+c1.getString(tname));
            }else if(i==1)
            {
                list3.add(c1.getString(tid));
                list4.add("BANNED"+"      "+c1.getString(tname));

            }
        }

        ArrayAdapter arrayAdapter1 = new ArrayAdapter<String>(ManageTravellerActivity.this, android.R.layout.simple_list_item_1, list4);
        mulv.setAdapter(arrayAdapter1);
        flag=0;

    }
    public  void showsnake() {
        Cursor c5=obj.getonetravelller(id1);
        String button;
        int sid=c5.getColumnIndex("actstatus");
        c5.moveToFirst();
        int data=c5.getInt(sid);
        if (data==0){
            button="Disable";
        }else {
            button="Enable";
        }
        final Snackbar snackbar = Snackbar.make(clayout, "Change Account Status?", Snackbar.LENGTH_INDEFINITE).setAction(button, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changestatus();
                Snackbar snackbar1 = Snackbar.make(clayout, "Account Status Changed Successfully!!!", Snackbar.LENGTH_SHORT);
                snackbar1.show();
                if (flag==0){
                    searchbind();
                }
                else if (flag==1){
                    listbind();
                }else {

                }
            }
        });
        snackbar.show();
    }
    public void startconfig(){
        travet1=(EditText)findViewById(R.id.travet1);
        trabtn1=(Button)findViewById(R.id.search);
        mulv=(ListView)findViewById(R.id.mulv);
        clayout=(CoordinatorLayout) findViewById(R.id.clayout);
        reftra=(Button)findViewById(R.id.reftra);
    }
    public void changestatus(){
        Cursor c=obj.getonetravelller(id1);
        int tid=c.getColumnIndex("tid");
        int sid=c.getColumnIndex("actstatus");
        c.moveToFirst();
        int data=c.getInt(sid);
        if (data==0) {
            if (obj.banaccount(id1,1)) {
                Toast.makeText(this, "Account Banned!!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Operation Failed", Toast.LENGTH_SHORT).show();
            }
        }else{
            if (obj.banaccount(id1, 0)) {
                Toast.makeText(this, "Account Activated!!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Operation Failed", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
