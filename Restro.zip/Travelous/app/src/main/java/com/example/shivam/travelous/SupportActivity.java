package com.example.shivam.travelous;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.pm.PackageManager;

public class SupportActivity extends AppCompatActivity {
EditText support1,support2;
Button support3,support4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_support);
        support1=findViewById(R.id.support1);
        support2=findViewById(R.id.support2);
        support3=findViewById(R.id.support3);
        support4=findViewById(R.id.support4);
        support3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title=support1.getText().toString();
                String description=support2.getText().toString();
                Intent intent=new Intent(Intent.ACTION_SEND);
                intent.setData(Uri.parse("mail to:"));
                intent.setType("text/plain");
                String[] t={"shivamkahar869@gmail.com"};
                intent.putExtra(Intent.EXTRA_EMAIL,t);
                intent.putExtra(Intent.EXTRA_SUBJECT,title);
                intent.putExtra(Intent.EXTRA_TEXT,description);
                try
                {
                    startActivity(new Intent(Intent.createChooser(intent,"Send Email")));
                    finish();
                }
                catch (Exception ex)
                {
                    Toast.makeText(getApplicationContext(), ex.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
        support4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Call
                String num="8160141489";
                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:" + num));
                if (ActivityCompat.checkSelfPermission(SupportActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
            }startActivity(intent);
            }
        });
    }
}
