package com.example.shivam.travelous;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MyPlacesActivity extends AppCompatActivity {
RecyclerView muplaces;
DbHelper obj;
String name,email;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_places);
        obj=new DbHelper(this);
        muplaces=findViewById(R.id.myplaces);
        final String hostname=getIntent().getStringExtra("hostname");
        final String hostemail=getIntent().getStringExtra("hostemail");
        name=hostname;
        email=hostemail;
        Cursor c1 = obj.gethostid(hostname, hostemail);
        int valid = c1.getColumnIndex("hid");
        c1.moveToFirst();
        int id = c1.getInt(valid);
        Cursor d = obj.showpropertybyid(id);
        int propertyname = d.getColumnIndex("pname");
        int propertyaddress=d.getColumnIndex("paddress");
        int proimage=d.getColumnIndex("proimage1");
        int pid=d.getColumnIndex("pid");
        List<Myplaces> properties = new ArrayList<>();
        int i = 0;
        if (d.getCount() != 0) {
            while (d.moveToNext()) {
                Myplaces property1 = new Myplaces(d.getString(propertyname),d.getString(propertyaddress),d.getInt(pid),d.getBlob(proimage));
                properties.add(i, property1);
                i++;
            }

            MyplacesAdapter adapter = new MyplacesAdapter(properties,this);
            muplaces.setAdapter(adapter);
            muplaces.setLayoutManager((new LinearLayoutManager(this)));
        }else{
            Toast.makeText(MyPlacesActivity.this, "There is no data to show!",Toast.LENGTH_LONG).show();
        }
    }

}

