package com.example.shivam.travelous;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class AddCityActivity extends AppCompatActivity {
    EditText ecet1;
    Button ecbtn1,ecbtn2;
    DbHelper obj;
    Spinner acsp1;
    ArrayList<String>list,list1;
    int id1;
    String get;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_city);
        startconfig();
        obj=new DbHelper(this);
        listbind();
        acsp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String id34=list.get(position);
                get=id34;
                String m=list1.get(position);
                id1=Integer.parseInt(m);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ecbtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String state = ecet1.getText().toString();
                try {
                    if (obj.addcity(state,id1)) {
                        Toast.makeText(AddCityActivity.this, "City Added", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(AddCityActivity.this, "City Not Added", Toast.LENGTH_SHORT).show();
                    }
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
        ecbtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(AddCityActivity.this,UpdateCityActivity.class);
                startActivity(i);
            }
        });
    }
    public void listbind()
    {
        list = new ArrayList<String>();
        list1=new ArrayList<>();
        Cursor c = obj.getData();
        int cidindex = c.getColumnIndex("sid");
        int cnameindex = c.getColumnIndex("sname");
        while(c.moveToNext())
        {
            list.add(c.getString(cnameindex));
            list1.add(c.getString(cidindex));

        }
        ArrayAdapter arrayAdapter = new ArrayAdapter<String>
                (AddCityActivity.this,android.R.layout.simple_list_item_1,list);
        acsp1.setAdapter(arrayAdapter);
    }
    public void startconfig(){
        ecet1=(EditText)findViewById(R.id.ecet1);
        ecbtn1=(Button)findViewById(R.id.ecbtn1);
        ecbtn2=(Button)findViewById(R.id.ecbtn2);
        acsp1=(Spinner)findViewById(R.id.acsp1);
    }
}