package com.example.shivam.travelous;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class RegisterActivity extends AppCompatActivity {
    Button rebtn1,test1;
    EditText et3,et4,et5,et6;
    DbHelper obj;
    Spinner rsp1;
    Integer posi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        obj=new DbHelper(this);
        startconfig();
        String[]opt={"Host","Traveller"};

        //for testing only
        /*test1=(Button)findViewById(R.id.test1);
        test1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent i=new Intent(getApplicationContext(),SetupHprofileActivity.class);
               startActivity(i);
            }
        });*/


        ArrayAdapter<String>arrayAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,opt);
       rsp1.setAdapter(arrayAdapter);
        rsp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                posi=position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

           }
        });

        rebtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String host="host";
                String traveller="traveller";
                String name=et3.getText().toString();
                String email=et4.getText().toString();
                String pwd=et5.getText().toString();
                String contact=et6.getText().toString();
                if (!isNullRec(name)){
                    et3.setError("Field Can't Be Empty");
                }
                if (!isNullRec(email)){
                    et4.setError("Field Can't Be Empty");
                }
                if (!isNullRec(pwd)){
                    et5.setError("Field Can't Be Empty");
                }
                if (!isNullRec(contact)){
                    et6.setError("Field Can't Be Empty");
                }
                if (!isValidContact(contact)){
                    et6.setError("Enter Valid Mobile Number");
                }
                if (!isValidEmail(email)){
                    et4.setError("Enter A Valid Email Address");
                }
                if (!isValidpassword(pwd)){
                    et5.setError("Enter More Than 6 Characters");
                }
                if ((isNullRec(name))&&(isNullRec(email))&&(isNullRec(pwd))&&(isNullRec(contact))&&(isValidEmail(email))&&(isValidpassword(pwd))&&(isValidContact(contact))) {


                    try {
                        if (posi == 0) {
                            Intent i = new Intent(getApplicationContext(), ConfirmOTPActivity.class);
                            i.putExtra("name", name);
                            i.putExtra("email", email);
                            i.putExtra("pwd", pwd);
                            i.putExtra("contact", contact);
                            i.putExtra("regas", host);
                            startActivity(i);
                        }
                        if (posi == 1) {
                            Intent i = new Intent(getApplicationContext(), ConfirmOTPActivity.class);
                            i.putExtra("name", name);
                            i.putExtra("email", email);
                            i.putExtra("pwd", pwd);
                            i.putExtra("contact", contact);
                            i.putExtra("regas", traveller);
                            startActivity(i);
                        }
                    } catch (Exception ex) {
                        showmsg(ex.toString());
                    }
                }
            }
        });

    }
    public void startconfig()
    {
        rsp1=(Spinner)findViewById(R.id.rsp1);
        rebtn1 = (Button)findViewById(R.id.rebtn1);
        et3 = (EditText)findViewById(R.id.et3);
        et4 = (EditText)findViewById(R.id.et4);
        et5 = (EditText)findViewById(R.id.et5);
        et6=(EditText)findViewById(R.id.et6);
    }
    public void showmsg(String msg)
    {
        Toast.makeText(this,msg, Toast.LENGTH_SHORT).show();
    }
    public void clrtxt()
    {
        et3.setText("");
        et4.setText("");
        et5.setText("");
    }
    private boolean isNullRec(String n)
    {
        if(n!="" && n.length() > 0)
        {
            return true;
        }
        return false;
    }
    private boolean isValidpassword(String p)
    {
        if(p!=null&&p.length()>6)
        {
            return true;
        }
        return false;
    }

    private boolean isValidEmail(String email){

        return Pattern.compile("^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$").matcher(email).matches();
    }

    private boolean isValidContact(String contact)
    {
        if(contact.length()==10)
        {
            return true;
        }
        return false;
    }

}



