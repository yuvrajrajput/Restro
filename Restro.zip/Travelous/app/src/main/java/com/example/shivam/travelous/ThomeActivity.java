package com.example.shivam.travelous;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class ThomeActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    TextView t1,t2;
    CardView home,restaurant,tab1;
    DbHelper obj;
    CircleImageView view1;
    RecyclerView thomerv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thome);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View headerview = navigationView.getHeaderView(0);
        t1 = (TextView) headerview.findViewById(R.id.travellername);
        t2 = (TextView) headerview.findViewById(R.id.travelleremail);
        tab1 =  findViewById( R.id.tab1 );
        thomerv = findViewById(R.id.thomerv);
        view1 = headerview.findViewById(R.id.thomeimage);
        final String name = getIntent().getStringExtra("name").toString();
        final String email = getIntent().getStringExtra("email").toString();
        t1.setText(name);
        t2.setText(email);
        //get pic
        obj = new DbHelper(this);
        Cursor c1 = obj.gettravellerid(name, email);
        final int valid = c1.getColumnIndex("tpic");
        byte[] image;
        c1.moveToFirst();
//        image = c1.getBlob(valid);
 //       if (image!=null) {
 //           view1.setImageBitmap(BitmapFactory.decodeByteArray(image, 0, image.length));
 //       }
        home = (CardView) findViewById(R.id.thome);
        restaurant = (CardView) findViewById(R.id.trestaurant);
        Cursor d = obj.showproperty();
        tab1.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),Pizza.class);
                startActivity( i );
            }
        } );
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(),BrowseHomeActivity.class);
                startActivity(i);
            }
        });
        restaurant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(),BrowseRestaurantActivity.class);
                startActivity(i);
            }
        });
        int propertyname = d.getColumnIndex("pname");
        int propertyaddress=d.getColumnIndex("paddress");
        int proimage=d.getColumnIndex("proimage1");
        int pid=d.getColumnIndex("pid");
        List<Property> properties = new ArrayList<>();
        int i = 0;
        if (d.getCount() != 0) {
            while (d.moveToNext()) {
                Property property1 = new Property(d.getString(propertyname),d.getString(propertyaddress),d.getInt(pid),d.getBlob(proimage),name,email);
                properties.add(i, property1);
                i++;
            }
            RecyclerViewAdapter adapter = new RecyclerViewAdapter(properties,this);
            thomerv.setAdapter(adapter);
            thomerv.setLayoutManager((new LinearLayoutManager(this)));
        }else{
            Toast.makeText(ThomeActivity.this, "There is no data to show!",Toast.LENGTH_LONG).show();
        }
        }
        public void putextraa(Intent i){
        String name=getIntent().getStringExtra("name");
        String email=getIntent().getStringExtra("email");
        i.putExtra("tname",name);
        i.putExtra("temail",email);
        }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.thome, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_tprofile) {
            Intent i=new Intent(getApplicationContext(),travellerprofileActivity.class);
            putextraa(i);
            startActivity(i);
            // Handle the camera action
        } else if (id == R.id.nav_thomes) {
            Intent i=new Intent(getApplicationContext(),BrowseHomeActivity.class);
            putextraa(i);
            startActivity(i);

        } else if (id == R.id.nav_trestaurants) {
            Intent i = new Intent(getApplicationContext(), BrowseRestaurantActivity.class);
            putextraa(i);
            startActivity(i);

        } else if (id == R.id.nav_tsupport) {
            Intent i=new Intent(getApplicationContext(),SupportActivity.class);
            startActivity(i);

        }else if(id==R.id.nav_tlogout){
            Intent i=new Intent(getApplicationContext(),MainActivity.class);
            startActivity(i);
            finish();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
