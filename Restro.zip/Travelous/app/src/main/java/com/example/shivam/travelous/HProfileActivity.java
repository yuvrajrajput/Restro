package com.example.shivam.travelous;

import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;

import de.hdodenhof.circleimageview.CircleImageView;

public class HProfileActivity extends AppCompatActivity {
    CircleImageView iv1;
    TextView tv1,tv2,tv3,tv4,tv5;
    DbHelper obj;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hprofile);
        String name=getIntent().getStringExtra("name");
        String email=getIntent().getStringExtra("email");
        startconfig();
        byte[] image2 = new byte[0];
        obj=new DbHelper(this);
        Cursor c=obj.gethostid(name,email);
        c.moveToFirst();
        int image1=c.getColumnIndex("hpic");

        int state=c.getColumnIndex("sid");
        int city=c.getColumnIndex("cid");
        image2=c.getBlob(image1);
        iv1.setImageBitmap(BitmapFactory.decodeByteArray(image2,0,image2.length));
        tv1.setText(name);
        tv2.setText(email);
        c.moveToFirst();
        int sid=c.getInt(state);
        int cid=c.getInt(city);
        Cursor c1=obj.getstatename(sid);
        Cursor c2=obj.getcityname(cid);
        c1.moveToFirst();
        c2.moveToFirst();
        String sname=c1.getString(c1.getColumnIndex("sname"));
        String cname=c2.getString(c2.getColumnIndex("cname"));
        tv3.setText(sname);
        tv4.setText(cname);

         String Cno=c.getString(c.getColumnIndex("hcontactno"));
         tv5.setText(Cno);

    }

    public void startconfig()
    {
        iv1=(CircleImageView)findViewById(R.id.iv1);
        tv1=(TextView)findViewById(R.id.tv1);
        tv2=(TextView)findViewById(R.id.tv2);
        tv3=(TextView)findViewById(R.id.tv3);
        tv4=(TextView)findViewById(R.id.tv4);
        tv5=(TextView)findViewById(R.id.tv5);
    }
}
