package com.example.shivam.travelous;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.*;
import java.util.ArrayList;

public class UpdateDeleteActivity extends AppCompatActivity {
ListView uslv1;
ArrayList<String>list,list1,list2;
DbHelper obj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_delete);
        uslv1=(ListView)findViewById(R.id.uslv1);

        obj = new DbHelper(this);
        listbind();
        uslv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final String state=list2.get(position);
                Intent i=new Intent(getApplicationContext(),UpdateStateActivity.class);
                i.putExtra("abcd",state);
                startActivity(i);
                finish();
            }
        });
    }

    public void listbind()
    {
        list = new ArrayList<String>();
        list1 =new ArrayList<String>();
        list2=new ArrayList<String>();
        Cursor c=obj.getData();
        int sidindex = c.getColumnIndex("sid");
        int snameindex = c.getColumnIndex("sname");


        while(c.moveToNext())
        {
            list.add(c.getString(sidindex) + "    " + c.getString(snameindex));
            list1.add(c.getString(snameindex));
            list2.add(c.getString(sidindex));
        }
        ArrayAdapter arrayAdapter = new ArrayAdapter<String>
                (UpdateDeleteActivity.this,android.R.layout.simple_list_item_1,list);
        uslv1.setAdapter(arrayAdapter);
    }

}
