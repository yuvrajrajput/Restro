package com.example.shivam.travelous;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class PaymentActivity extends AppCompatActivity {
DbHelper obj;
Button pay;
TextView finalprice;
EditText cardno,expmonth,expyear,cvv,nameoncard;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        obj=new DbHelper(this);
        startconfig();
        final String tname=getIntent().getStringExtra("tname");
        final String temail=getIntent().getStringExtra("temail");
        final String pname=getIntent().getStringExtra("pname");
        final String amount=getIntent().getStringExtra("amount");
        final String indate=getIntent().getStringExtra("indate");
        final String outdate=getIntent().getStringExtra("outdate");
        finalprice.setText(amount);
        //final int hid=c.getColumnIndex("hid");
        //final String proid=c.getString(hid);
        //final String hostid=c.getString(hid);
        /* final String pid=c.getString(c.getColumnIndex("pid"));
         final String hid=c.getString(c.getColumnIndex("hid"));
         final String s1=ttid;
         final String s2=pid;
         final String s3=hid;*/

        pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             Toast.makeText( getApplicationContext(),"Wait A Second" , Toast.LENGTH_LONG ).show();
                Intent i = new Intent(getApplicationContext(),PaymentsuccesfulActivity.class);
                startActivity( i );
            }
        });
    }
    public void startconfig(){
        pay=findViewById(R.id.pay);
        cardno=findViewById(R.id.cardno);
        cvv=findViewById(R.id.cvv);
        expmonth=findViewById(R.id.expmonth);
        expyear=findViewById(R.id.expyear);
        nameoncard=findViewById(R.id.nameoncard);
        finalprice=findViewById(R.id.final_price);
    }
    private boolean isNullRec(String n)
    {
        if(n!="" && n.length() > 0)
        {
            return true;
        }
        return false;
    }
    private boolean isValidcard(String contact)
    {
        if(contact.length()==16)
        {
            return true;
        }
        return false;
    }
    private boolean isValidcvv(String contact)
    {
        if(contact.length()==3)
        {
            return true;
        }
        return false;
    }
    private boolean isValidm(String contact)
    {
        if(contact.length()==2)
        {
            return true;
        }
        return false;
    }
    private boolean isValidy(String contact)
    {
        if(contact.length()==4)
        {
            return true;
        }
        return false;
    }
}
