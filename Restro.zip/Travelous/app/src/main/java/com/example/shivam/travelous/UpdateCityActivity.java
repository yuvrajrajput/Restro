package com.example.shivam.travelous;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class UpdateCityActivity extends AppCompatActivity {
    ListView uclv1;
    ArrayList<String> list2,list3,list4;
    DbHelper obj;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_city);
        uclv1 = (ListView) findViewById(R.id.uclv1);

        obj = new DbHelper(this);
        listbind();
        uclv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final String city = list3.get(position);
                Intent i = new Intent(UpdateCityActivity.this, UpdatedeleteCityActivity.class);
                i.putExtra("efgh",city);
                startActivity(i);
                finish();
            }
        });
    }

    public void listbind()
    {
        list2 = new ArrayList<String>();
        list3 = new ArrayList<String>();
        list4 = new ArrayList<String>();
        Cursor c = obj.getcityData();
        int cidindex = c.getColumnIndex("cid");
        int cnameindex = c.getColumnIndex("cname");
        int sidindex=c.getColumnIndex("sid");
        //list4.add("cid"+"  "+"sid"+"    "+"cname");
        while(c.moveToNext())
        {

            list2.add(c.getString(cnameindex));
            list3.add(c.getString(cidindex));
            list4.add("  "+c.getString(cidindex)+"     "+c.getString(sidindex)+"     "+c.getString(cnameindex));
        }
        ArrayAdapter arrayAdapter = new ArrayAdapter<String>
                (UpdateCityActivity.this,android.R.layout.simple_list_item_1,list4);
        uclv1.setAdapter(arrayAdapter);
    }

}