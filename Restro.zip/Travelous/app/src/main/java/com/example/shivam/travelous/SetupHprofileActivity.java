package com.example.shivam.travelous;

import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ScaleDrawable;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class SetupHprofileActivity extends AppCompatActivity {
Spinner spsp1,spsp2;
EditText spet1;
CircleImageView c1;
Button sphbtn1,sphbtn2;
ArrayList<String> list,list1,list2,list3,list4,list5;
DbHelper obj;
FloatingActionButton fab;
final int REQUEST_CODE_GALLERY=999;
int stateid,cityid,selctedcity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setup_hprofile);
        obj=new DbHelper(this);
        startconfig();
        final String name=getIntent().getStringExtra("name").toString();
        final String email=getIntent().getStringExtra("email").toString();
        final String pwd=getIntent().getStringExtra("pwd").toString();
        final String contact=getIntent().getStringExtra("contact");
        //getintentdata();
        list = new ArrayList<String>();
        list2 = new ArrayList<String>();
        spinner1();
        spinner2();
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent,REQUEST_CODE_GALLERY);
            }
        });
        spsp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                String m=list1.get(position);
                stateid=Integer.parseInt(m);
                citybind();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spsp2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String m=list3.get(position);
                cityid=Integer.parseInt(m);
                String s=list4.get(position);
                Cursor c=obj.getonescity(s);
                int c1=c.getColumnIndex("cid");
                c.moveToFirst();
                selctedcity=c.getInt(c1);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        sphbtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Toast.makeText(SetupHprofileActivity.this,name+"\n"+email+"\n"+pwd+"\n"+contact, Toast.LENGTH_SHORT).show();
                String aadhar=spet1.getText().toString().trim();
                if (!isValidAdhar(aadhar)){
                    spet1.setError("Enter a Valid Aadhar Number");
                }
                if (!isNullRec(aadhar)){
                    spet1.setError("Field Can't Be Empty");
                }
                if ((isValidAdhar(aadhar))&&(isNullRec(aadhar))){


                if (obj.addhost(name,email,pwd,contact,stateid,selctedcity,aadhar,imageviewtobyte(c1))){
                    Toast.makeText(SetupHprofileActivity.this, "Registration Successful!!", Toast.LENGTH_SHORT).show();
                    Intent i=new Intent(getApplicationContext(),HhomeActivity.class);
                    i.putExtra("name",name);
                    i.putExtra("email",email);
                    i.putExtra("pwd",pwd);
                    i.putExtra("contact",contact);
                    startActivity(i);
                    finish();
                }
                else{
                    Toast.makeText(SetupHprofileActivity.this, "Registration Failed!", Toast.LENGTH_SHORT).show();
                }
            }}
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        // Check which request it is that we're responding to
        // Make sure the request was successful
        if(requestCode==REQUEST_CODE_GALLERY && resultCode==RESULT_OK && data!=null) {
            // Get the URI that points to the selected contact
            Uri uri = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                c1.setImageBitmap(bitmap);
                showmsg("Image Display");

            } catch (Exception ex) {
                showmsg(ex.getMessage());
            }

        }
        super.onActivityResult(requestCode, resultCode, data);
    }
    public void showmsg(String s){
        Toast.makeText(this, s.toString(), Toast.LENGTH_SHORT).show();
    }
   /* public void getintentdata(){
        String name=getIntent().getStringExtra("name").toString();
        String email=getIntent().getStringExtra("email").toString();
        String pwd=getIntent().getStringExtra("pwd").toString();
        String contact=getIntent().getStringExtra("contact");
    }*/
    public void startconfig(){
        spsp1=(Spinner)findViewById(R.id.spsp1);
        spsp2=(Spinner)findViewById(R.id.spsp2);
        spet1=(EditText)findViewById(R.id.spet1);
        sphbtn2=(Button)findViewById(R.id.sphbtn2);
        fab=findViewById(R.id.fab1);
        c1=findViewById(R.id.addhpro);
    }
    public void spinner1() {

        {
            list = new ArrayList<String>();
            list1 = new ArrayList<>();
            Cursor c = obj.getData();
            int sidindex = c.getColumnIndex("sid");
            int snameindex = c.getColumnIndex("sname");
            while (c.moveToNext()) {
                list.add(c.getString(snameindex));
                list1.add(c.getString(sidindex));
            }
            ArrayAdapter arrayAdapter = new ArrayAdapter<String>
                    (SetupHprofileActivity.this, android.R.layout.simple_list_item_1, list);
            spsp1.setAdapter(arrayAdapter);
        }
    }
        public void spinner2(){
            list2 = new ArrayList<String>();
            list3 = new ArrayList<>();
            Cursor c = obj.getcityData();
            int cidindex = c.getColumnIndex("cid");
            int cnameindex = c.getColumnIndex("cname");
            int sidindex1=c.getColumnIndex("sid");
            while (c.moveToNext()) {
                list2.add(c.getString(cnameindex));
                list3.add(c.getString(cidindex));
            }
            ArrayAdapter arrayAdapter = new ArrayAdapter<String>
                    (SetupHprofileActivity.this, android.R.layout.simple_list_item_1, list2);
            spsp2.setAdapter(arrayAdapter);
        }
        public void citybind(){
            list4 = new ArrayList<String>();
            list5 = new ArrayList<>();
            Cursor c = obj.getscitydata(stateid);
            int cidindex = c.getColumnIndex("cid");
            int cnameindex = c.getColumnIndex("cname");
            int sidindex1=c.getColumnIndex("sid");
            while (c.moveToNext()) {
                list4.add(c.getString(cnameindex));
                list5.add(c.getString(cidindex));
            }
            ArrayAdapter arrayAdapter = new ArrayAdapter<String>
                    (SetupHprofileActivity.this, android.R.layout.simple_list_item_1, list4);
            spsp2.setAdapter(arrayAdapter);
        }
    public byte[] imageviewtobyte(ImageView imageView)
    {
        Bitmap bitmap=((BitmapDrawable)imageView.getDrawable()).getBitmap();
        ByteArrayOutputStream stream=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,100,stream);
        byte[] bytearray=stream.toByteArray();
        return bytearray;
    }
    private boolean isValidAdhar(String adhar){

        if(adhar.length()==12){
            return true;
        }
        return false;
    }
    private boolean isNullRec(String n)
    {
        if(n!="" && n.length() > 0)
        {
            return true;
        }
        return false;
    }

}
